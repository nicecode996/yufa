# -*- coding: utf8 -*-
"""setting page
"""

from shoots_android.control import *
from uibase.upath import *
import logging


class SettingPanel(Window):
    """setting window
    """
    window_spec = {"activity": "com.ss.android.ugc.live.manager.SettingActivity"}

    def get_locators(self):
        return {
            "退出登录":{"type": Control, "path": UPath(text_ == "退出登录")},
            "确定": {"type": Control, "path": UPath(text_ == "确定")},
        }

    def logout(self, device):
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, 4 * device.screen_rect.height // 5,
            device.screen_rect.width // 2, device.screen_rect.height // 5))
        self["退出登录"].click()
        self["确定"].click()
        self.app.wait_for_activity("com.ss.android.ugc.live.main.MainActivity")


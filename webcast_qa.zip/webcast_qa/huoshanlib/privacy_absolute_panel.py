# -*- coding: utf8 -*-
"""privacy page
"""

from shoots_android.control import *
from uibase.upath import *
import logging


class PrivacyWindow(Window):
    """privacy window
    """
    window_spec = {"activity": "com.ss.android.ugc.live.privacy.PrivacyAbsoluteActivity"}

    def get_locators(self):
        return {
            "个人信息保护指引": {"type": Control, "path": UPath(id_ == "title", text_ == "个人信息保护指引")},
            #"个人信息保护指引": {"type": Control, "path": UPath(text_ == "个人信息保护指引",visible_==True)},
            #"我知道了": {"type": Control, "path": UPath(id_ == "i_know", text_ == "我知道了")},
            "我知道了": {"type": Control, "path": UPath(text_ == "我知道了",visible_==True)},
            "同意": {"type": Control, "path": UPath(id_ == "agree_btn", text_ == "同意")},#1.6.8版本之后的变更
        }

    def init(self):
        if self["个人信息保护指引"].existing:
            print("个人信息")
            if self["同意"].wait_for_visible(timeout=5,raise_error=False):
                self["同意"].click()

            if self["我知道了"].wait_for_visible(timeout=4,raise_error=False):
                self["我知道了"].click()
            time.sleep(15)
        else:
            time.sleep(8)
            if self["个人信息保护指引"].existing:
                print("个人信息")
                if self["同意"].wait_for_visible(timeout=5, raise_error=False):
                    self["同意"].click()

                if self["我知道了"].wait_for_visible(timeout=4, raise_error=False):
                    self["我知道了"].click()
                time.sleep(15)

# -*- coding: UTF-8 -*-
from shoots_android.control import *
from uibase.upath import *


class GrantPopup(Window):
    '''
    抖火授权弹窗
    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "同 意": {"type": Control, "path": UPath(id_ == "tv_vcd_grant_yes", text_ == "同 意")},
            "授权提示": {"type": Control, "path": UPath(id_ == "tv_vcd_grant_title", text_ == "授权提示")},
        }

    def handler(self):
        if self['同 意'].existing:
            self['同 意'].click()
            time.sleep(1)
            return not self['同 意'].existing
        return False

class UpgradePopup(Window):
    '''
    升级弹窗页面
    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "以后再说": {'type': TextView, 'path': UPath(id_ == "later_btn", text_ == "以后再说")},
        }

    def handler(self):
        if self['以后再说'].existing:
            self['以后再说'].click()
            time.sleep(1)
            return not self['以后再说'].existing
        return False

class IknowPopup(Window):
    '''

    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "我知道了": {"type": Control, "path": UPath(id_ == "close", text_ == "我知道了")},
        }

    def handler(self):
        if self['我知道了'].existing:
            self['我知道了'].click()
            time.sleep(1)
            return not self['我知道了'].existing
        return False

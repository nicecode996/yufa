# -*- coding: utf8 -*-
"""anchor living room
"""

from shoots_android.control import *
from uibase.upath import *
import logging
from byted_cv.ocr_helper import find_pic, click_pic
from settings import PROJECT_ROOT
import os


resoureces_path = PROJECT_ROOT + "/resources/images/"

class AnchorLivingRoom(Window):
    """anchor living room
    """
    window_spec = {"activity": "com.bytedance.android.livesdkproxy.activity.LiveBroadcastActivity"}

    def get_locators(self):
        return {
            """
            '关闭': {'type': Control, 'path': UPath(id_ == 'close', visible_ == True)},
            "结束页关闭按钮": {"type": Control, "path": UPath(id_ == "back_to_main")},
            "动作按钮": {"type": Control, "path": UPath(id_ == "action_container")},
            "礼物": {"type": Control, "root": "动作按钮", "path": UPath(index=7)},
            "礼物列表": {"type": Control, "path": UPath(id_ == 'list')},
            "礼物": {"type": Control, "root": "礼物列表", "path": UPath(index=0)},
            "赠送按钮": {"type": Control, "path": UPath(id_ == "send")},
            "页面中间": {"type": Control, "path": UPath(id_ == "ttlive_anchor_task_finish_animation_view")},
            "小礼物托盘": {"type": Control, "path": UPath(id_ == "base_gift_view")},
            "大礼物托盘": {"type": Control, "path": UPath(id_ == "user_view")},
            "提示": {"type": Control, "path": UPath(id_ == "live_dialog_title", text_ == "提示")},
            "确定": {"type": Control, "path": UPath(id_ == "live_dialog_btn_1", text_ == "确定")},
            "点击屏幕，进入涂鸦模式":{"type": Control, "path": UPath(text_ == "点击屏幕，进入涂鸦模式")},
            "涂鸦礼物关闭按钮": {"type": Control, "path": UPath(id_ == "close_dialog")},
            "主播id":{'type': Control, 'path': UPath(id_ == 'anchor_info_container')}"""

            "重要通知": {"type": Control, "path": UPath(text_ == "重要通知")},
            "继续直播": {"type": Control, "path": UPath(text_ == "继续直播")},
            # "关播A": {"type": Control, "path": UPath(id_ == "close")},
            # "关播B": {"type": Control, "path": UPath(id_ == "action_container")/UPath(index=3)},
            "提示": {"type": Control, "path": UPath(text_ == "提示")},
            "确定": {"type": Control, "path": UPath(text_ == "确定")},
            "主播信息": {"type": Control, "path": UPath(id_ == "anchor_info_container")},
            "结束页关闭按钮": {"type": Control, "path": UPath(id_ == "back_to_main")},
            "结束页关闭按钮插件版": {"type": Control, "path": UPath(id_ == "l_")},
            "动作按钮": {"type": Control, "path": UPath(id_ == "action_container")},
            "关播新样式": {"type": Control, "root": "动作按钮", "path": UPath(index=3)},
            "更多": {"type": Control, "root": "动作按钮", "path": UPath(id_=="more")},
            # "更多上的黄点":{"type":Control, "root": "动作按钮", "path": UPath(id_ == "view_red_dot")},
            "更多面板": {"type": Control, "path": UPath(id_ == "grid_layout")},
            "页面中间": {"type": Control, "path": UPath(id_ == "ttlive_anchor_task_finish_animation_view")},
            "礼物": {"type": Control, "root": "更多面板", "path": UPath(text_ == "礼物")},
            "粉丝团": {"type": Control, "root": "更多面板", "path": UPath(text_ == "粉丝团")},
            "礼物列表": {"type": Control, "path": UPath(id_ == 'list')},
            "礼物a": {"type": Control, "root": "礼物列表", "path": UPath(index=0)},
            "礼物b": {"type": Control, "root": "礼物列表", "path": UPath(index=1)},
            "发送按钮": {"type": Control, "path": UPath(id_ == "send")},
            "小礼物托盘": {"type": Control, "path": UPath(id_ == "base_gift_view")},
            "大礼物托盘": {"type": Control, "path": UPath(id_ == "user_view")},
            "左右滑动切换滤镜": {"type": Control, "path": UPath(text_ == "左右滑动切换滤镜")},
            "礼物面板关闭按钮": {"type": Control, "path": UPath(id_ == "close_btn_view")},
            "检测到你的封面为空，影响新观众进来看你直播。请点击上传封面！": {"type": Control, "path": UPath(text_ == "检测到你的封面为空，影响新观众进来看你直播。请点击上传封面！")},
        }

    def Scroll(self):
        if self["左右滑动切换滤镜"].existing:
            if self["左右滑动切换滤镜"].visible:
                print("左右滑动切换滤镜")
                self["左右滑动切换滤镜"].click()

    def continueliving(self):
        try:
            if self["重要通知"].visible:
                print("hahha")
                self["继续直播"].click()
                self["重要通知"].wait_for_invisible()
            if self["检测到你的封面为空，影响新观众进来看你直播。请点击上传封面！"].visible:
                print("hahha")
                self["继续直播"].click()
                self["检测到你的封面为空，影响新观众进来看你直播。请点击上传封面！"].wait_for_invisible()
        except:
            pass

    def BroadcastSuccesful(self):
        time.sleep(3)
        if self["主播信息"].visible:
            return 0
        else:
            return 1

    def endBroadcastSuccesful(self):
        if self["结束页关闭按钮"].visible:
            return 0
        else:
            return 1

    def closeliving(self,device):

        # 通过byted-cv 点击退出直播间功能（165版本之后）
        if find_pic(driver=device, target_path=os.path.join(resoureces_path, 'close_live.png')):
            print("找到了图片资源")
            click_pic(driver=device, target_path=os.path.join(resoureces_path, 'close_live.png'))
            if not self["提示"].wait_for_visible(raise_error=False):
                click_pic(driver=device, target_path=os.path.join(resoureces_path, 'close_live.png'))
        else:
            # 直接通过按钮点击
            time.sleep(5)
            if self["关播新样式"].visible:
                self["关播新样式"].click()
                    #点击无效新增点击重试
                if not self["提示"].wait_for_visible(raise_error=False):
                    self["关播新样式"].click()

        self["提示"].wait_for_visible()
        self["确定"].click()
        #time.sleep(15)
        if self["结束页关闭按钮"].wait_for_visible(timeout=10,raise_error=False):
           self["结束页关闭按钮"].click()

        elif self["结束页关闭按钮插件版"].wait_for_visible(timeout=10,raise_error=False):
           self["结束页关闭按钮插件版"].click()

        self.app.wait_for_activity("com.ss.android.ugc.live.main.MainActivity")


    def sendGifta(self,device):
        try:
            # 通过byted-cv 点击更多按钮（165版本之后）
            if find_pic(driver=device, target_path=os.path.join(resoureces_path, 'more_message.png')):
                click_pic(driver=device, target_path=os.path.join(resoureces_path, 'more_message.png'))

            # 开直播方式2
            else:
                # 失败重试
                time.sleep(5)
                if find_pic(driver=device, target_path=os.path.join(resoureces_path, 'more_message.png')):
                    click_pic(driver=device, target_path=os.path.join(resoureces_path, 'more_message.png'))
            #self["更多"].click()
            time.sleep(2)
            if self["更多面板"].wait_for_visible(timeout=10, raise_error=False):
                print("打开更多面板")
            else:
                self["页面中间"].click()
                time.sleep(5)
                self["更多"].click()
                time.sleep(5)
        except:
            self["页面中间"].click()
            time.sleep(5)
            self["更多"].click()
            time.sleep(2)
            self["更多面板"].wait_for_visible(timeout=10, raise_error=False)

        if self["礼物"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物"].click()
            time.sleep(5)
        if self["礼物a"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物a"].click()
            self["发送按钮"].click()
            for _ in Retry(timeout=10, interval=0.1, raise_error=False):
                if self["小礼物托盘"].existing:
                    if self["小礼物托盘"].visible:
                        return 0
                if self["大礼物托盘"].existing:
                    if self["大礼物托盘"].visible:
                        return 0
            return 1


    def sendGiftSuccesful(self):
        for _ in Retry(timeout=10, interval=0.2, raise_error=False):
            if self["小礼物托盘"].existing or self["大礼物托盘"].existing:
                time.sleep(10)
                return 0
        else:
            return 1

    def closeGiftpanel(self):
        if self["礼物列表"].existing:
            self._device_driver.send_key(4)


# -*- coding: utf8 -*-
"""before start living
"""

from shoots_android.control import *
from uibase.upath import *
from huoshanlib.record_panel import RecordPanel
import logging

class BeforeStartLiving(Window):
    """before start living
    """
    window_spec = {"activity": "com.ss.android.ugc.live.tools.window.RecorderActivity"}

    def get_locators(self):
        return {
            "开始视频直播": {"type": Control, "path": UPath(text_ == "开始视频直播")},
            "直播": {"type": Control, "path": UPath(id_=="item_text",text_ == "直播")},
            "直播意外中断了, 是否继续直播?": {"type": Control, "path": UPath(text_ == "直播意外中断了, 是否继续直播?")},
            "取消": {"type": Control, "path": UPath(text_ == "取消")},
            "同 意": {"type": Control, "path": UPath(id_ == "tv_vcd_grant_yes", text_ == "同 意")},
            "授权提示": {"type": Control, "path": UPath(id_ == "tv_vcd_grant_title", text_ == "授权提示")},
        }

    def start_living(self):
        time.sleep(5)
        if self["直播"].wait_for_visible(timeout=10,raise_error=False):
            self["直播"].click()

        if self["直播意外中断了, 是否继续直播?"].existing:
            self["取消"].click()
        #等待弹窗消失
        time.sleep(15)

        for _ in Retry(timeout=700, interval=1, raise_error=False):
            if self["开始视频直播"].existing:
                if self["开始视频直播"].visible:
                    self["开始视频直播"].click()
                    time.sleep(5)
                    if self["授权提示"].existing:
                        self["同 意"].click()
                    return True
        else:
            raise Exception("开始视频直播处发生错误")


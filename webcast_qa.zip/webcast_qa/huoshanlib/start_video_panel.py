# -*- coding: utf8 -*-
"""start video page
"""

from shoots_android.control import *
from uibase.upath import *
import logging


class StartVideo(Window):
    """start video window
    """
    window_spec = {"activity": "com.ss.android.ugc.live.detail.DetailActivity"}

    def get_locators(self):
        return {
            "关闭": {"type": Control, "path": UPath(id_ == "close", index=0)}
        }

    def close(self):
        self["关闭"].click()
        time.sleep(5)
        if self["关闭"].existing:
            self["关闭"].click()
            time.sleep(5)

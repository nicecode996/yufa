# -*- coding: utf8 -*-
"""living room page
"""

from shoots_android.control import *
from uibase.upath import *
import logging

class LivingRoom(Window):
    """living room
    """
    window_spec = {"activity": "com.ss.android.ugc.live.live.ui.LiveDetailActivity"}

    def get_locators(self):
        return {
            '关闭': {'type': Control, 'path': UPath(id_ == 'close_btn', visible_ == True)},
            "主播id":{'type': Control, 'path': UPath(id_ == 'user_name', index=0)},
            "关注": {"type": Control, "path": UPath(id_ == "follow", text_ == "关注")},
            "关注主播不再错过精彩直播": {"type": Control, "path": UPath(id_ == "room_center_content", text_ == "关注主播不再错过精彩直播")},
            "退出": {"type": Control, "path": UPath(id_ == "room_center_button_left", text_ == "退出")},
            "您正在直播中，是否继续直播？": {"type": Control, "path": UPath(text_ == "您正在直播中，是否继续直播？")},
            "结束直播": {"type": Control, "path": UPath(text_ == "结束直播")}
        }

    def isliving(self):
        if self["结束直播"].existing:
            self["结束直播"].click()
        time.sleep(10)

    def isWctchingLive(self, device):
        if self["主播id"].existing:
            return 0
        else:
            return 1

    def quit_room(self):
        self["关闭"].click()
        time.sleep(2)
        if self["关注主播不再错过精彩直播"].existing:
            self["退出"].click()
        if self["关闭"].existing:
            self["关闭"].click()
            if self["关注主播不再错过精彩直播"].existing:
                self["退出"].click()
            time.sleep(5)
        if self["关闭"].existing:
            self["关闭"].click()
            if self["关注主播不再错过精彩直播"].existing:
                self["退出"].click()
            time.sleep(5)

    def swipe_to_next_room(self, device):
        old_anchor_name = self.get_anchor_name()
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, 3*device.screen_rect.height // 7,
            device.screen_rect.width // 2, device.screen_rect.height // 30))
        time.sleep(15)
        if self.get_anchor_name() != old_anchor_name:
            return 0
        else:
            return 1

    def get_anchor_name(self):
        print(self["主播id"].text)
        return self['主播id'].text

    def follow_anchor(self,device):
        if self["关注"].visible:
            self["关注"].click()
            time.sleep(5)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
            if not self["关注"].visible:
                return 0
        else:
            while not self["关注"].visible:
                self.swipe_to_next_room(device)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
                if self["关注"].visible:
                    self["关注"].click()
                    time.sleep(5)
                if self["关注"].visible:
                    self["关注"].click()
                    time.sleep(5)
                if not self["关注"].visible:
                    return 0
            else:
                return 1

# -*- coding: utf8 -*-
"""record page
"""

from shoots_android.control import *
from uibase.upath import *
import logging


class RecordPanel(Window):
    """record window
    """
    window_spec = {"activity": "com.ss.android.ugc.live.tools.window.RecorderActivity"}

    def get_locators(self):
        return {
            "直播意外中断了, 是否继续直播?": {"type": Control, "path": UPath(id_ == "live_dialog_message", text_ == "直播意外中断了, 是否继续直播?")},
            "取消":{"type": Control, "path": UPath(id_ == "live_dialog_btn_2", text_ == "取消")}
        }

    def Record(self):
        if self["直播意外中断了, 是否继续直播?"].existing:
            self["取消"].click()
            time.sleep(5)
        else:
            pass

# -*- coding: UTF-8 -*-
from xigualib.testcase import XiGuaTest, XiGuaTestBase
from xigualib.app import XiGuaApp
from xigualib.main import StartWindow
from xigualib.living_room_panel import LivingRoom
import time
from webcastlib.mobile_account import MobileRequest

"""
    case:关注主播
"""

class FollowAnchor(XiGuaTestBase):
    """关注
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'xigua'
    ip = ''

    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = XiGuaApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("登陆")
        self.home.init()
        self.home.open_main_page("我的")
        time.sleep(5)
        num = self.home.log_in(self.device)
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "xigua_follow_anchor"}))

        self.start_step("点击直播，进入直播间")
        self.home.open_live_room()
        time.sleep(8)
        living_room = LivingRoom(root=self.app)
        living_room.app.wait_for_activity(living_room.activity)
        living_room.isliving()
        self.assert_("未成功观看直播", (living_room.isWatchingLive(self.device) == 0) & (self.device.current_activity == "com.ixigua.feature.live.LivePlayerActivity"))

        self.start_step("关注主播")
        flag = living_room.follow_anchor(self.device)
        self.assert_("未成功关注主播",flag == 0)

        self.start_step("点击关闭，退出直播间")
        living_room.quit_room(self.device)
        main_panel = StartWindow(root=self.app)
        main_panel.app.wait_for_activity(main_panel.activity)

        # self.start_step("退出登录")
        # self.home.log_out(self.device)
        # 加上了app启动时初始化，去掉退出登录

        g = MobileRequest()
        g.release_num(tags=32, num=num)

if __name__ == '__main__':
    go = FollowAnchor()
    go.debug_run()

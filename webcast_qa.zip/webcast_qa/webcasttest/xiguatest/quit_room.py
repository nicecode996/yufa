# -*- coding: UTF-8 -*-
from xigualib.testcase import XiGuaTest
from xigualib.app import XiGuaApp
from xigualib.main import StartWindow
from xigualib.living_room_panel import LivingRoom
import time

"""
    case:退出直播间
"""

class QuitRoom(XiGuaTest):
    """退房
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'xigua'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = XiGuaApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("点击直播，进入直播间")
        self.home.init()
        self.home.open_live_room()
        time.sleep(5)
        living_room = LivingRoom(root=self.app)
        living_room.app.wait_for_activity(living_room.activity)
        living_room.isliving()
        self.assert_("未成功观看直播", living_room.isWatchingLive(self.device) == 0)

        self.start_step("点击关闭，退出直播间")
        living_room.quit_room(self.device)
        main_panel = StartWindow(root=self.app)
        main_panel.app.wait_for_activity(main_panel.activity)


if __name__ == '__main__':
    go = QuitRoom()
    go.debug_run()

# -*- coding: UTF-8 -*-
import time

from xigualib.app import XiGuaApp
from xigualib.login_panel import LoginPanel
from xigualib.main import StartWindow
from xigualib.testcase import XiGuaTest, XiGuaTestBase
from xigualib.anchor_living_room_panel import AnchorLivingRoom
from webcastlib.mobile_account import MobileRequest

"""
    case:关播
"""

class CloseLiving(XiGuaTestBase):
    """关播
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'xigua'
    ip = ''

    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = XiGuaApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("登陆")
        self.home.init()
        self.home.open_main_page("我的")
        time.sleep(5)
        num = self.home.log_in(self.device)
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "xigua_start_living"}))

        self.start_step("开播")
        self.home.open_main_page("我的")
        self.home.start_living(self.device)
        living_room = AnchorLivingRoom(root=self.app)
        self.assert_("未成功开始直播", (living_room.StartLivingSuccesful(self.device)==0) & (self.device.current_activity =="com.ixigua.feature.live.LiveBroadcastActivity"))

        self.start_step("关播")
        living_room.ClosingLiving()
        self.assert_("未成功关闭直播", (self.device.current_activity == "com.ss.android.article.video.activity.SplashActivity"))

        #self.start_step("退出登录")
        #self.home.log_out(self.device)
        # 加上了app启动时初始化，去掉退出登录
        g = MobileRequest()
        g.release_num(tags=32, num=num)

if __name__ == '__main__':
    go = CloseLiving()
    go.debug_run()

# -*- coding: utf8 -*-

from shoots_android.control import Window, Control, TextView
from shoots_android.upath import UPath, desc_, id_
from shoots_android.androidapp import AccessibilityApp
from shoots_android.androidtestbase import AndroidTestBase
from OtherApp.Kuaishoulib.main import MainPanel
from OtherApp.Kuaishoulib.live_room import LiveRoom
from OtherApp.Kuaishoulib.app import KuaishouApp
import time

class SearchRankPeopleTest(AndroidTestBase):
    """送礼
        """
    owner = "tanjianxin"
    timeout = 3000

    def run_test(self):
        self.start_step("启动快手")
        self.device = self.acquire_device()
        self.app = KuaishouApp(self.device)

        self.start_step("检测登录")
        main = MainPanel(root=self.app)
        main.login()

        self.start_step("进入直播间")

        main.enter_live(self.device)
        liveRoom = LiveRoom(root=self.app)
        self.assert_("未进入直播间", liveRoom.window_spec["activity"] == self.app.current_activity)

        self.start_step("获取直播小时榜的数据")
        liveRoom.search_list()


if __name__ == "__main__":
    SearchRankPeopleTest().debug_run()

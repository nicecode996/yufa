# -*- coding: UTF-8 -*-
from douyinlib.testcase import DouyinTest
from douyinlib.app import DouYinApp
from douyinlib.main_panel import MainWindow
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.living_square_panel import LiveSquare
from douyinlib.common.address_book_friends_panel import FriendPanel
from douyinlib.common.living_room_panel import WatchLiving
from douyinlib.common.start_video_panel import StartVideo
from douyinlib.common.start_living_panel import StartLiving
import time
import logging
"""
case: 进房
"""

class GoInLiveRoom(DouyinTest):
    """
    进房
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'douyin'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = DouYinApp(self.device)
        self.home = MainWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("case1 打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        self.home.init(self.device)
        time.sleep(10)
        self.home.init(self.device)

        self.start_step("点击LIVE，进入直播间")
        time.sleep(5)
        self.home.open_live_page()
        live_room = WatchLiving(root=self.app)
        live_room.app.wait_for_activity(live_room.activity)
        live_room.isliving()
        live_room.scroll_to_nextroom(self.device)
        live_room.scroll_to_nextroom(self.device)
        live_room.scroll_until_not_media_living_room(self.device)
        self.assert_("未成功观看直播", live_room.isWctchingLive(self.device) == 0)

if __name__ == '__main__':
    go = GoInLiveRoom()
    go.debug_run()





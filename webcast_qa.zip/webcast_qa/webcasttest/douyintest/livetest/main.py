# -*- coding: UTF-8 -*-

"""
    case执行函数，线下调试用
"""

from webcasttest.douyintest.livetest.start_living_case import StartLiveRoom
from webcasttest.douyintest.livetest.watch_living_case import GoInLiveRoom
from webcasttest.douyintest.livetest.scroll_to_nextroom import ScrollToNextroom
from webcasttest.douyintest.livetest.quit_room import QuitRoom
from webcasttest.douyintest.livetest.fllow_anchor import FollowAnchor

if __name__ == '__main__':
    times = 5
    import logging

    LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"

    logging.basicConfig(filename='../log/my.log', level=logging.DEBUG, format=LOG_FORMAT)
    '''
    logging.debug("This is a debug log.")
    logging.info("This is a info log.")
    logging.warning("This is a warning log.")
    logging.error("This is a error log.")
    logging.critical("This is a critical log.")
    '''
    for i in range(times):
        case1_go = GoInLiveRoom()
        case1_go.debug_run()

        case2_go = StartLiveRoom()
        case2_go.debug_run()

        case4_go = ScrollToNextroom()
        case4_go.debug_run()

        case5_go = QuitRoom()
        case5_go.debug_run()

        case6_go = FllowAnchor()
        case6_go.debug_run()


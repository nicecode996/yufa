# -*- coding: UTF-8 -*-
import time

from douyinlib.app import DouYinApp
from douyinlib.common.AnchorLivingRoom_panel import AnchorLivingRoom
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.start_living_panel import StartLiving
from douyinlib.common.start_video_panel import StartVideo
from douyinlib.main_panel import MainWindow
from douyinlib.testcase import DouyinTest,DouyinTestBase
from douyinlib.common.address_book_friends_panel import  FriendPanel
from shoots import logger
from webcastlib.mobile_account import MobileRequest
from douyinlib.common.setting_panel import SettingPanel

"""
    case:送礼
"""

class AnchorSendGift(DouyinTestBase):
    """
    送礼
    """
    owner = "wuting.scnc"
    timeout = 1500
    app = 'douyin'
    ip = ''
    runtimes = 10
    clear_data = True


    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = DouYinApp(self.device)
        self.home = MainWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("case1 打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        self.home.init(self.device)
        time.sleep(10)
        self.home.init(self.device)

        self.start_step("确保已经登录")
        self.home.open_main_page("我")

        time.sleep(5)

        #检测登录是否成功
        # if self.device.get_current_activity() == "com.ss.android.ugc.aweme.account.white.login.DYLoginActivity":
        #     login_panel = LoginPanel(root = self.app)
        #     num = login_panel.login()
        #     #mobile = self.resmgr.acquire("account", conditions={"tags":"1128"})
        #     #login_panel.login(self.device, mobile)
        #     time.sleep(10)
        #
        #     if self.device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
        #         friend_panel = FriendPanel(root=self.app)
        #         friend_panel.skip()
        # else:
        #     logger.warning("未经过登录")
        num = self.home.checked_login(self.device)
        self.assert_("未登录",num!=0)

        time.sleep(5)
        self.home.open_main_page("首页")
        time.sleep(2)
        self.home.init(self.device)
        time.sleep(5)

        """开播操作"""
        self.start_step("进入开播页")
        self.home.init(self.device)
        time.sleep(2)
        self.home.start_new_live()
        time.sleep(5)

        self.start_step("开始你的直播")
        start_video = StartVideo(root=self.app)
        self.app.wait_for_activity(start_video.activity)
        start_video.start_living()
        anchorlivingroom = AnchorLivingRoom(root=self.app)
        self.app.wait_for_activity(anchorlivingroom.activity,timeout=50)
        time.sleep(10)
        anchorlivingroom.continueliving()
        anchorlivingroom.Scroll()

        time.sleep(15)
        """送礼case"""
        self.start_step("送礼")
        anchor_living_room = AnchorLivingRoom(root=self.app)
        anchor_living_room.sendGifta()

        # if flaga == 0:
        #     pass
        # else:
        #     logger.warning("校验送出礼物失败，待通过日志解决")
        #     #raise RuntimeError("未成功赠送小礼物")
        # time.sleep(5)
        time.sleep(10)
        anchorlivingroom.closeGiftpanel()
        #通过直播间消息检测是否送礼物成功
        time.sleep(5)
        flag = anchorlivingroom.sendGiftSuccesful()
        if flag == 0:
            pass
        else:
            logger.warning("校验送出礼物失败，待通过日志解决")
            #raise RuntimeError("未成功赠送小礼物")
        time.sleep(5)
        self.start_step("关播")
        anchorlivingroom.closeliving()
        time.sleep(15)

        self.assert_("未成功关闭直播", (self.device.current_activity == self.home.getActivity()))

        self.start_step("退出登录")
        time.sleep(3)
        #判断是否有设置抖音号的弹窗
        self.home.init(self.device)

        self.home.open_main_page("我")
        self.home.init(self.device)
        self.home.logout(self.device)
        #setting_panel = SettingPanel(root=self.app)
        #setting_panel.logout(self.device)

        g = MobileRequest()
        g.release_num(tags = 1128,  num = num)

if __name__ == '__main__':
    go = AnchorSendGift()
    go.debug_run()



# -*- coding: UTF-8 -*-
from douyinlib.testcase import DouyinTest,DouyinTestBase
from douyinlib.app import DouYinApp
from douyinlib.main_panel import MainWindow
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.address_book_friends_panel import  FriendPanel
from douyinlib.common.living_room_panel import WatchLiving
from douyinlib.common.start_video_panel import StartVideo
from douyinlib.common.start_living_panel import StartLiving
import time
from shoots import logger
from webcastlib.mobile_account import MobileRequest
from douyinlib.common.setting_panel import SettingPanel
"""
case: 关注
"""

class FollowAnchor(DouyinTestBase):
    """
    关注
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'douyin'
    ip = ''
    clear_data = True


    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = DouYinApp(self.device)
        self.home = MainWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("case1 打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        self.home.init(self.device)
        time.sleep(8)
        self.home.init(self.device)


        self.start_step("确保已经登录")
        self.home.open_main_page("我")
        time.sleep(5)

        # if self.device.get_current_activity() == "com.ss.android.ugc.aweme.account.white.login.DYLoginActivity":
        #     login_panel = LoginPanel(root=self.app)
        #     num = login_panel.login()
        #     #login_panel.login(self.device, self.resmgr.acquire("account",conditions={"tags":"douyin_follow_anchor"}))
        #     time.sleep(10)
        #
        #     if self.device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
        #         friend_panel = FriendPanel(root=self.app)
        #         friend_panel.skip()
        # time.sleep(5)

        num = self.home.checked_login(self.device)
        self.assert_("未登录", num != 0)

        time.sleep(5)
        self.home.open_main_page("首页")
        time.sleep(2)
        self.home.init(self.device)
        time.sleep(5)

        self.start_step("打开LIVE")
        self.home.init(self.device)
        time.sleep(7)
        self.home.open_live_page()
        live_room = WatchLiving(root=self.app)
        live_room.app.wait_for_activity(live_room.activity)
        live_room.isliving()
        live_room.scroll_to_nextroom(self.device)
        live_room.scroll_to_nextroom(self.device)
        live_room.scroll_until_not_media_living_room(self.device)
        time.sleep(5)

        self.start_step("关注主播")
        WatchLiving_panel = WatchLiving(root=self.app)
        self.assert_("未成功关注主播",
                    WatchLiving_panel.follow_anchor(self.device) == 0)

        self.start_step("退出直播间")
        WatchLiving_panel = WatchLiving(root=self.app)
        WatchLiving_panel.quit_room()
        mainpanel = MainWindow(root=self.app)
        mainpanel.app.wait_for_activity(mainpanel.activity)
        time.sleep(5)
        self.assert_("未成功退出直播",
                     self.device.current_activity == "com.ss.android.ugc.aweme.main.MainActivity")

        #self.start_step("退出登录")
        #self.home.open_main_page("我")
        #self.home.logout(self.device)
        #setting_panel = SettingPanel(root=self.app)
        #setting_panel.logout(self.device)

        g = MobileRequest()
        g.release_num(tags=1128, num=num)


if __name__ == '__main__':
    go = FollowAnchor()
    go.debug_run()



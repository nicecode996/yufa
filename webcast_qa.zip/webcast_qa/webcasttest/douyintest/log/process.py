# -*- coding: UTF-8 -*-
import re


def extract(line):
    # 未成功观看直播
    # 成功进入直播间开播
    pattern = "成功进入直播间开播"
    regex = re.compile(pattern)
    matcher = regex.findall(line)
    return matcher


if __name__ == '__main__':
    fp = open("my.log")
    for line in fp.readlines():  # 遍历每一行
        res = extract(line)
        if res != []:
            print(extract(line))

    fp.close()

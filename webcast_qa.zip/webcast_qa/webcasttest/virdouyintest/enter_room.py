# -*- coding: UTF-8 -*-
from virdouyinlib.testcase import virDouYinTest
from virdouyinlib.app import virdouyinApp
from virdouyinlib.main import StartWindow
import time

"""
    case:抖音虚拟环境，进入直播间
"""

class EnterRoom(virDouYinTest):
    """进入直播间
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'virdouyin'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = virdouyinApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("进房")
        flag = self.home.go_to_room()
        self.assert_("进入直播feed失败，网络问题点击重试", flag == 0)
        time.sleep(10)

        self.assert_("未成功进入直播间",
                     self.device.current_activity == "com.bytedance.android.ttlivesdk.live.LivePlayerActivity")


if __name__ == '__main__':
    go = EnterRoom()
    go.debug_run()

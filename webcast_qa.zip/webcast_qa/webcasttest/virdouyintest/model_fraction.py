# -*- coding: UTF-8 -*-
from virdouyinlib.testcase import virDouYinTest
from virdouyinlib.apps import virdouyinApps
from virdouyinlib.app import virdouyinApp

from virdouyinlib.main import StartWindow
from shoots.test_result import EnumLogLevel,LogRecord
import time
from shoots_android.androidapp import AndroidApp
import re
from shoots_android import util
import requests
import json
from virdouyinlib.AnchorLivingRoomPanel import AnchorLivingRoom
from webcastlib.mobile_account import MobileRequest
from virdouyinlib.LiveStartPanel import StartLiving
from virdouyinlib.settingPage import setPage
from webcasttest.virdouyintest.model_rate import ModelRate
"""
    case:抖音虚拟环境，直播间打分
"""

class ModelFraction(virDouYinTest):
    """直播间打分
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'virdouyin'
    ip = ''


    def run_test(self):
        self.device = self.acquire_device()
        self.app = virdouyinApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("开启boe")
        self.home.open_set()
        setpages = setPage(root=self.app)
        setpages.open_boe()

        self.start_step("重启app")
        self.app.restart(clear_data=False)
        # self.device = self.acquire_device()
        # self.app = virdouyinApps(self.device)
        # self.home = StartWindow(root=self.app)
        #
        self.start_step("登录")
        num = self.home.log_in_boe()
        # self.home.log_in(self.resmgr.acquire("account", conditions={"tags":"virdouyin_startlive"}))
        time.sleep(5)

        self.start_step("开播")
        self.home.start_living()
        start_live = StartLiving(root=self.app)
        anchorlivingroom = AnchorLivingRoom(root=self.app)
        anchorlivingroom.app.wait_for_activity(anchorlivingroom.activity)

        self.assert_("未成功开播",
                     anchorlivingroom.isAnchorLivingRoom())


        self.start_step("获取机型打分")
        time.sleep(10)

        self.log_info(anchorlivingroom.get_width_massage())
        anchor_model_rate = re.findall(r"width:(.*)", anchorlivingroom.get_width_massage())[0]

        print(anchor_model_rate)
        model = self.device.model

        self.get_screen_shot(self.device,"截图")
        reply = self.get_reply(model)
        self.log_info(anchor_model_rate)
        anchor_ve_rate = self.get_anchor_score(reply)
        anchor_ve_rates = self.get_gate((int)(anchor_model_rate))

        self.assert_("机型打分与VE返回打分不匹配", (anchor_ve_rate==anchor_ve_rates))


    def get_gate(self,wight):

        if wight<=500:
            return '3'
        elif wight >=700:
            return '1'
        else:
            return '2'

    def get_screen_shot(self,app_or_device,info):
        device = app_or_device
        if isinstance(app_or_device, AndroidApp):
            device = app_or_device._device
        path = self.__class__.__name__ + '_' + util.get_valid_file_name(device.serial) + '_' + str(
            int(time.time())) + '.jpg'
        device.screenshot(path)
        self.test_result.info(info, LogRecord(attachments={'截图': path}))


    def get_reply(self,model):

        url = 'http://effect.snssdk.com/vecloud/api/benchmark/v2/model_score?platform=1&model_name=%s' % model
        return requests.get(url).json()

    def get_anchor_score(self,reply):
        s = json.dumps(reply)
        s1 = json.loads(s)
        score = s1["data"]["VideoRecordScene"]
        self.log_info("VE_anchor_score:%s" % score)

        if score < 5.92:
            return '3'
        elif score >= 7.92:
            return '1'
        else:
            return '2'


if __name__ == '__main__':
    go = ModelFraction()
    go.debug_run()


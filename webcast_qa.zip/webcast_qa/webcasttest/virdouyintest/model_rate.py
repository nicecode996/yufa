# -*- coding: UTF-8 -*-
from virdouyinlib.testcase import virDouYinTest
from virdouyinlib.app import virdouyinApp
from virdouyinlib.main import StartWindow
from shoots.test_result import EnumLogLevel,LogRecord
import time
from shoots_android.androidapp import AndroidApp
import re
from shoots_android import util
import requests
import json


"""
    case:抖音虚拟环境，机型打分
"""

class ModelRate(virDouYinTest):
    """进入直播间
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'virdouyin'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = virdouyinApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("获取机型打分")
        time.sleep(10)

        self.log_info(self.home.get_model_rate())
        anchor_model_rate = re.findall(r"LIVE_MODEL_RATE_ANCHOR : (.*)", self.home.get_model_rate())[0]
        audience_model_rate = re.findall(r"LIVE_MODEL_RATE_AUDIENCE : (.*)", self.home.get_model_rate())[0]
        model = re.findall(r"MODEL : (.*)", self.home.get_model_rate())[0]


        self.get_screen_shot(self.device,"截图")
        reply = self.get_reply(model)

        anchor_ve_rate = self.get_anchor_score(reply)
        audience_ve_rate = self.get_audience_score(reply)
        print(anchor_ve_rate)
        print(audience_ve_rate)

        self.assert_("机型打分与VE返回打分不匹配", (anchor_model_rate == anchor_ve_rate) & (audience_model_rate == audience_ve_rate))



    def get_screen_shot(self,app_or_device,info):
        device = app_or_device
        if isinstance(app_or_device, AndroidApp):
            device = app_or_device._device
        path = self.__class__.__name__ + '_' + util.get_valid_file_name(device.serial) + '_' + str(
            int(time.time())) + '.jpg'
        device.screenshot(path)
        self.test_result.info(info, LogRecord(attachments={'截图': path}))


    def get_reply(self,model):

        url = 'http://effect.snssdk.com/vecloud/api/benchmark/v2/model_score?platform=1&model_name=%s' % model
        return requests.get(url).json()

    def get_anchor_score(self,reply):
        s = json.dumps(reply)
        s1 = json.loads(s)
        score = s1["data"]["VideoRecordScene"]
        self.log_info("VE_anchor_score:%s" % score)

        if score < 5.92:
            return '3'
        elif score >= 7.92:
            return '1'
        else:
            return '2'

    def get_audience_score(self, reply):
        s = json.dumps(reply)
        s1 = json.loads(s)
        score = s1["data"]["OverallScore"]
        self.log_info("VE_audience_score:%s" % score)

        if score < 5.50:
            return '3'
        elif score >= 7.31:
            return '1'
        else:
            return '2'




if __name__ == '__main__':
    go = ModelRate()
    go.debug_run()

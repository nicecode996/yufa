# -*- coding: UTF-8 -*-
from virdouyinlib.testcase import virDouYinTest
from virdouyinlib.app import virdouyinApp
from virdouyinlib.main import StartWindow
from virdouyinlib.AnchorLivingRoomPanel import AnchorLivingRoom
import time
from webcastlib.mobile_account import MobileRequest

"""
    case:抖音虚拟环境，开播
"""

class StartLiving(virDouYinTest):
    """开播
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'virdouyin'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = virdouyinApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        #self.home._device_driver.send_key(4) #收起键盘
        self.start_step("登录")
        num = self.home.log_in()
        #self.home.log_in(self.resmgr.acquire("account", conditions={"tags":"virdouyin_startlive"}))
        time.sleep(5)

        self.start_step("开播")
        self.home.start_living()
        anchorlivingroom = AnchorLivingRoom(root=self.app)
        anchorlivingroom.app.wait_for_activity(anchorlivingroom.activity)

        self.assert_("未成功开播",
                     anchorlivingroom.isAnchorLivingRoom())
        #time.sleep(2)
        #anchorlivingroom.Scroll()
        #time.sleep(2)
        #anchorlivingroom.closeliving()

        g = MobileRequest()
        g.release_num(tags=1128, num=num)


if __name__ == '__main__':
    go = StartLiving()
    go.debug_run()

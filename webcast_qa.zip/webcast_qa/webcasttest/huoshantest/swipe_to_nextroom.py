# -*- coding: utf8 -*-
"""上下滑
"""

from huoshanlib.testcase import huoshanTest
from huoshanlib.app import huoshanApp
from huoshanlib.main import StartWindow
from huoshanlib.privacy_absolute_panel import PrivacyWindow
from huoshanlib.living_room_panel import LivingRoom
from huoshanlib.start_video_panel import StartVideo
from shoots.retry import Retry
import time


class SwipeToNextRoom(huoshanTest):
    """上下滑
    """
    owner = "tanjianxin"
    timeout = 600

    def run_test(self):
        self.device = self.acquire_device()
        self.app = huoshanApp(self.device)
        self.home = StartWindow(root=self.app)
        time.sleep(6)
        #self.home.wait_for_loading()

        self.start_step("打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        privacy_panel = PrivacyWindow(root=self.app)
        privacy_panel.init()
        if self.device.current_activity == "com.ss.android.ugc.live.detail.DetailActivity":
            print("启动小视频")
            # start_video = StartVideo(root=self.app)
            # start_video.close()
            self.device.send_key(4)
        self.home.init()

        self.start_step("进入直播间")
        self.home.open_live_page()
        self.home.init()
        self.home.enter_room_from_feed()
        live_room = LivingRoom(root=self.app)
        live_room.app.wait_for_activity(live_room.activity)
        live_room.isliving()
        self.assert_("未成功观看直播", (live_room.isWctchingLive(self.device) == 0)& (self.device.current_activity == "com.ss.android.ugc.live.live.ui.LiveDetailActivity"))

        self.start_step("上滑至下一直播间")
        live_room.swipe_to_next_room(self.device)
        time.sleep(10)
        live_room.swipe_to_next_room(self.device)
        time.sleep(10)
        flag = live_room.swipe_to_next_room(self.device)
        time.sleep(5)
        self.assert_("未成功切换直播间", flag == 0)

if __name__ == '__main__':
    go = SwipeToNextRoom()
    go.debug_run()

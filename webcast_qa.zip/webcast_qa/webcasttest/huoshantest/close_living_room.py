# -*- coding: utf8 -*-
"""关播
"""

from huoshanlib.testcase import huoshanTest, huoshanTestBase
from huoshanlib.app import huoshanApp
from huoshanlib.main import StartWindow
from huoshanlib.privacy_absolute_panel import PrivacyWindow
from huoshanlib.living_room_panel import LivingRoom
from huoshanlib.start_video_panel import StartVideo
from huoshanlib.record_panel import RecordPanel
from huoshanlib.AnchorLivingRoom import AnchorLivingRoom
from huoshanlib.before_start_living import BeforeStartLiving
from shoots.retry import Retry
import time
from shoots import logger
from webcastlib.mobile_account import MobileRequest


class CloseLivingRoom(huoshanTestBase):
    """关播
    """
    owner = "tanjianxin"
    timeout = 600
    clear_data = True

    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = huoshanApp(self.device)
        self.home = StartWindow(root=self.app)
        time.sleep(6)
        # self.home.wait_for_loading()

        self.start_step("打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        privacy_panel = PrivacyWindow(root=self.app)
        privacy_panel.init()
        if self.device.current_activity == "com.ss.android.ugc.live.detail.DetailActivity":
            print("启动小视频")
            # start_video = StartVideo(root=self.app)
            # start_video.close()
            self.device.send_key(4)
        privacy_panel.init()
        self.home.init()

        self.start_step("登陆")
        num = self.home.log_in()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "huoshan_send_gift"}))

        self.start_step("开播")
        self.home.start_living()
        record_panel = RecordPanel(root=self.app)
        record_panel.app.wait_for_activity(record_panel.activity, 50)
        before_start_living = BeforeStartLiving(root=self.app)
        before_start_living.start_living()
        anchorlivingroom = AnchorLivingRoom(root=self.app)
        anchorlivingroom.app.wait_for_activity(anchorlivingroom.activity, 100)
        time.sleep(10)
        anchorlivingroom.continueliving()
        anchorlivingroom.Scroll()


        self.start_step("关播")
        #self.get_screen_shot(self.device, "截图")#截取直播间图片
        anchorlivingroom.closeliving(self.device)
        time.sleep(15)
        self.assert_("未成功关闭直播", (self.device.current_activity == "com.ss.android.ugc.live.main.MainActivity"))

        #self.start_step("退出登录")
        #self.home.log_out(self.device)

        g = MobileRequest()
        g.release_num(tags = 1112, num=num)


if __name__ == '__main__':
    go = CloseLivingRoom()
    go.debug_run()

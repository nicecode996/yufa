# -*- coding: utf8 -*-
"""关注
"""

from huoshanlib.testcase import huoshanTest,huoshanTestBase
from huoshanlib.app import huoshanApp
from huoshanlib.main import StartWindow
from huoshanlib.privacy_absolute_panel import PrivacyWindow
from huoshanlib.living_room_panel import LivingRoom
from huoshanlib.start_video_panel import StartVideo
from shoots.retry import Retry
from webcastlib.mobile_account import MobileRequest
import time


class FollowAnchor(huoshanTestBase):
    """关注
    """
    owner = "tanjianxin"
    timeout = 600
    clear_data = True

    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = huoshanApp(self.device)
        self.home = StartWindow(root=self.app)
        time.sleep(6)
        #self.home.wait_for_loading()

        self.start_step("打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        privacy_panel = PrivacyWindow(root=self.app)
        privacy_panel.init()
        if self.device.current_activity == "com.ss.android.ugc.live.detail.DetailActivity":
            print("启动小视频")
            # start_video = StartVideo(root=self.app)
            # start_video.close()
            self.device.send_key(4)
        self.home.init()

        self.start_step("登陆")
        num = self.home.log_in()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "huoshan_follow_anchor"}))
        self.home.init()

        self.start_step("进入直播间")
        self.home.open_live_page()
        self.home.init()
        self.home.enter_room_from_feed()
        live_room = LivingRoom(root=self.app)
        live_room.app.wait_for_activity(live_room.activity)
        live_room.isliving()
        self.assert_("未成功观看直播", (live_room.isWctchingLive(self.device) == 0)& (self.device.current_activity == "com.ss.android.ugc.live.live.ui.LiveDetailActivity"))

        self.start_step("关注主播")
        flag = live_room.follow_anchor(self.device)
        self.assert_("未成功关注主播", flag == 0)

        self.start_step("点击关闭，退出直播间")
        live_room.quit_room()
        main_panel = StartWindow(root=self.app)
        main_panel.app.wait_for_activity(main_panel.activity)
        self.assert_("未成功退出直播",
                     self.device.current_activity == "com.ss.android.ugc.live.main.MainActivity")

        #self.start_step("退出登录")
        #self.home.log_out(self.device)
        g = MobileRequest()
        g.release_num(tags = 1112, num=num)

if __name__ == '__main__':
    go = FollowAnchor()
    go.debug_run()

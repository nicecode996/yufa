# -*- coding: UTF-8 -*-
from xigualib.testcase import XiGuaTest
from xigualib.app import XiGuaApp
from xigualib.main import StartWindow
from xigualib.living_room_panel import LivingRoom
import time
import os

"""
    case:退出直播间
"""

class QuitRoom(XiGuaTest):
    """退房
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'xigua'
    tags = 'publish_check_com.ss.android.liveplugin_32'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = XiGuaApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("点击直播，进入直播间")
        self.home.init()
        self.home.open_live_room()
        time.sleep(5)
        living_room = LivingRoom(root=self.app)

        living_room.app.wait_for_activity(living_room.activity)
        living_room.isliving()

        self.assert_("未成功观看直播", living_room.isWatchingLive(self.device) == 0)

        flag = self.if_test_watching_plugin()

        self.assert_("看播插件版本号与需测试版本号不同，检查输入版本号和插件链接地址", flag == 0)
        self.start_step("点击关闭，退出直播间")
        living_room.quit_room(self.device)
        main_panel = StartWindow(root=self.app)
        main_panel.app.wait_for_activity(main_panel.activity)
        self.assert_("未成功退出直播",
                     self.device.current_activity == "com.ss.android.article.video.activity.SplashActivity")


    def if_test_watching_plugin(self):
        # com_ss_android_liveplugin = "100000000"
        liveplugin_version = self.app.wait_plugin('com.ss.android.liveplugin', timeout=60)
        #liveresource_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)
        liveplugin_version_download = self.app.get_plugins_version("com.ss.android.liveplugin")
        #liveresource_version_download = self.app.get_plugins_version("com.ss.android.ies.live.liveresource")
        print(liveplugin_version_download)
        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已安装看播插件版本号：%s" % liveplugin_version)
        # liveresource_version = plugin_list['com.ss.android.ies.live.liveresource']
        #self.log_info("已安装开播插件版本号：%s" % liveresource_version)
        if (liveplugin_version is not None) and (liveplugin_version_download==liveplugin_version):
            return 0
        else:
            self.log_debug("需测试看播插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1
        # com_ss_android_liveplugin = os.environ.get("看播")  # 获取输入环境变量
        # self.log_info("需测试看播插件版本号：%s" % com_ss_android_liveplugin)
        # if (int(com_ss_android_liveplugin)) == (int(liveplugin_version)):
        #     self.log_info("需测试看播插件版本号和已安装看播插件版本号相同")
        #     return 0
        # else:
        #     self.log_debug("需测试看播插件版本号和已安装看播插件版本号不同")
        #     return 1

if __name__ == '__main__':
    go = QuitRoom()
    go.debug_run()

# -*- coding: UTF-8 -*-
import time

from xigualib.app import XiGuaApp
from xigualib.login_panel import LoginPanel
from xigualib.main import StartWindow
from xigualib.testcase import XiGuaTest, XiGuaTestBase
from xigualib.anchor_living_room_panel import AnchorLivingRoom
from webcastlib.mobile_account import MobileRequest
import os

"""
    case:关播
"""

class CloseLiving(XiGuaTestBase):
    """关播
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'xigua'
    ip = ''

    def run_test(self):
        #self.device = self.acquire_device()
        self.app = XiGuaApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("登陆")
        self.home.init()
        self.home.open_main_page("我的")
        time.sleep(5)
        num = self.home.log_in()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "xigua_start_living"}))
        flag = self.if_test_watching_plugin()
        self.assert_("看播插件版本号与需测试版本号不同，检查输入版本号和插件链接地址", flag == 0)

        self.start_step("开播")
        self.home.open_main_page("我的")
        self.home.start_living(self.device)
        living_room = AnchorLivingRoom(root=self.app)
        self.assert_("未成功开始直播", (living_room.StartLivingSuccesful(self.device)==0) & (self.device.current_activity =="com.ixigua.feature.live.LiveBroadcastActivity"))

        self.start_step("关播")
        living_room.ClosingLiving()
        self.assert_("未成功关闭直播", (self.device.current_activity == "com.ss.android.article.video.activity.SplashActivity"))

        #self.start_step("退出登录")
        #self.home.log_out(self.device)
        # 加上了app启动时初始化，去掉退出登录
        g = MobileRequest()
        g.release_num(tags=32, num=num)

    def if_test_watching_plugin(self):
        # com_ss_android_liveplugin = "100000000"
        liveplugin_version = self.app.wait_plugin('com.ss.android.liveplugin', timeout=60)
        liveresource_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)
        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已安装看播插件版本号：%s" % liveplugin_version)
        # liveresource_version = plugin_list['com.ss.android.ies.live.liveresource']
        self.log_info("已安装开播插件版本号：%s" % liveresource_version)

        if (liveplugin_version is not None) and (liveresource_version is not None):
            return 0
        else:
            self.log_debug("需测试看播插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1
        # com_ss_android_liveplugin = os.environ.get("看播")  # 获取输入环境变量
        # self.log_info("需测试看播插件版本号：%s" % com_ss_android_liveplugin)
        # if (int(com_ss_android_liveplugin)) == (int(liveplugin_version)):
        #     self.log_info("需测试看播插件版本号和已安装看播插件版本号相同")
        #     return 0
        # else:
        #     self.log_debug("需测试看播插件版本号和已安装看播插件版本号不同")
        #     return 1

if __name__ == '__main__':
    go = CloseLiving()
    go.debug_run()

# -*- coding: utf8 -*-
"""开播
"""

from huoshanlib.testcase import huoshanTest, huoshanTestBase
from huoshanlib.app import huoshanApp
from huoshanlib.main import StartWindow
from huoshanlib.privacy_absolute_panel import PrivacyWindow
from huoshanlib.living_room_panel import LivingRoom
from huoshanlib.start_video_panel import StartVideo
from huoshanlib.record_panel import RecordPanel
from huoshanlib.AnchorLivingRoom import AnchorLivingRoom
from huoshanlib.before_start_living import BeforeStartLiving
from shoots.retry import Retry
import time
from shoots import logger
from webcastlib.mobile_account import MobileRequest


class StartLiveHuoshan(huoshanTest):
    """开播
    """
    owner = "tanjianxin"
    timeout = 600
    app = 'huoshan'
    tags = 'publish_check_com.ss.android.ies.live.liveresource_1112'
    clear_data = True

    def run_test(self):
        self.device = self.acquire_device()
        self.app = huoshanApp(self.device)
        self.home = StartWindow(root=self.app)
        time.sleep(6)
        #self.home.wait_for_loading()

        self.start_step("打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        privacy_panel = PrivacyWindow(root=self.app)
        privacy_panel.init()
        if self.device.current_activity == "com.ss.android.ugc.live.detail.DetailActivity":
            print("启动小视频")
            # start_video = StartVideo(root=self.app)
            # start_video.close()
            self.device.send_key(4)
        privacy_panel.init()
        self.home.init()

        self.start_step("登陆")
        num = self.home.log_in_plus()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags": "huoshan_send_gift"}))

        self.start_step("开播")
        self.home.start_living()
        record_panel = RecordPanel(root=self.app)
        record_panel.app.wait_for_activity(record_panel.activity,50)
        before_start_living = BeforeStartLiving(root=self.app)
        before_start_living.start_living()
        anchorlivingroom = AnchorLivingRoom(root=self.app)
        anchorlivingroom.app.wait_for_activity(anchorlivingroom.activity,100)

        self.start_step("检测插件是否配置")
        flag = self.if_test_watching_plugin()
        self.assert_("插件配置失败", flag == 0)
        time.sleep(10)
        anchorlivingroom.continueliving()
        anchorlivingroom.Scroll()

        self.start_step("关播")
        anchorlivingroom.closeGiftpanel()
        anchorlivingroom.closeliving(self.device)
        time.sleep(15)
        self.assert_("未成功关闭直播", (self.device.current_activity == "com.ss.android.ugc.live.main.MainActivity"))

        #self.start_step("退出登录")
        #self.home.log_out(self.device)
        g = MobileRequest()
        g.release_num(tags = 1112, num = num)


    def if_test_watching_plugin(self):
        # com_ss_android_liveplugin = "100000000"
        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        liveplugin_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)

        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已经安装的插件版本信息：%s" % liveplugin_version)
        if (liveplugin_version is not None) and (liveplugin_version > 0 ):
            return 0
        else:
            self.log_debug("需测试插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1

if __name__ == '__main__':
    go = StartLiveHuoshan()
    go.debug_run()

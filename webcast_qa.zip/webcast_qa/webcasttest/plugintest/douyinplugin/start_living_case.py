# -*- coding: utf8 -*-

from douyinlib.testcase import DouyinTest,DouyinTestBase
from douyinlib.app import DouYinApp
from douyinlib.main_panel import MainWindow
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.living_square_panel import LiveSquare
from douyinlib.common.living_room_panel import WatchLiving
from douyinlib.common.start_video_panel import StartVideo
from douyinlib.common.start_living_panel import StartLiving
from douyinlib.common.address_book_friends_panel import  FriendPanel
from douyinlib.common.AnchorLivingRoom_panel import AnchorLivingRoom
import time
from webcastlib.mobile_account import MobileRequest
from douyinlib.common.setting_panel import SettingPanel
"""
case: 开播
"""

class DouyinbasePlusLiving(DouyinTest):
    """
    开播
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'douyin'
    tags = 'publish_check_com.ss.android.ies.live.liveresource_1128'
    ip = ''


    def run_test(self):

        self.device = self.acquire_device()
        self.app = DouYinApp(self.device)
        self.home = MainWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("case1 打开app-初始化，进入首页，弹窗处理")
        time.sleep(10)
        self.home.init(self.device)
        time.sleep(10)
        self.home.init(self.device)


        self.start_step("确保已经登录")
        self.home.init(self.device)
        self.home.open_main_page("我")
        time.sleep(5)

        if self.device.get_current_activity() == "com.ss.android.ugc.aweme.account.white.login.DYLoginActivity":
            login_panel = LoginPanel(root=self.app)
            num = login_panel.login()
            #login_panel.login(self.device, self.resmgr.acquire("account",conditions={"tags":"douyin_start_living"}))
            time.sleep(10)

            if self.device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
                friend_panel = FriendPanel(root=self.app)
                friend_panel.skip()
        time.sleep(5)
        self.home.open_main_page("首页")
        time.sleep(2)
        self.home.init(self.device)
        time.sleep(5)

        """开播操作"""
        self.start_step("进入开播页")
        self.home.init(self.device)
        time.sleep(2)
        self.home.start_new_live()
        time.sleep(5)

        self.start_step("开始你的直播")

        start_video = StartVideo(root=self.app)
        self.app.wait_for_activity(start_video.activity)
        start_video.start_living()
        time.sleep(20)
        self.start_step("检测插件是否配置")
        flag = self.if_test_watching_plugin()
        self.assert_("插件配置失败",flag==0)

        anchorlivingroom = AnchorLivingRoom(root=self.app)
        self.app.wait_for_activity(anchorlivingroom.activity)
        self.assert_("未成功开始直播", (anchorlivingroom.BroadcastSuccesful() == 0) & (
                self.device.current_activity == anchorlivingroom.activity))

        time.sleep(15)

        self.start_step("关播")
        anchorlivingroom.continueliving()
        time.sleep(2)
        anchorlivingroom.Scroll()
        anchorlivingroom.closeliving()
        time.sleep(10)
        self.assert_("未成功关闭直播", (self.device.current_activity == "com.ss.android.ugc.aweme.main.MainActivity"))

        #self.start_step("退出登录")
        #self.home.open_main_page("我")
        #self.home.logout(self.device)
        #setting_panel = SettingPanel(root=self.app)
        #setting_panel.logout(self.device)

        g = MobileRequest()  #释放账号
        g.release_num(tags=1128, num=num)


    def if_test_watching_plugin(self):

        # com_ss_android_liveplugin = "100000000"
        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        liveplugin_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)

        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已经安装的插件版本信息：%s" % liveplugin_version)
        if (liveplugin_version is not None) and (liveplugin_version > 0):
            return 0
        else:
            self.log_debug("需测试插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1


if __name__ == '__main__':
    go = DouyinbasePlusLiving()
    go.debug_run()

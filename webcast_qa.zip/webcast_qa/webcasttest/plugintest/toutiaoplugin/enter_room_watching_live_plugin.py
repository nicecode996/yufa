# -*- coding: utf8 -*-

from toutiaolib.testcase import TouTiaoTest
from toutiaolib.app import TouTiaoApp
from toutiaolib.main import StartWindow
from toutiaolib.living_room_panel import LivingRoom

import time
from shoots import logger
import os

"""
    case:进入直播间观看直播
"""

class WatchLiving(TouTiaoTest):
    """进房
    """
    owner = "tanjianxin"
    timeout = 1100
    app = 'toutiao'
    tags = 'publish_check_com.ss.android.liveplugin_13'
    ip = ''

    def run_test(self):
        self.device = self.acquire_device()
        self.app = TouTiaoApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        # self.home.init()
        # time.sleep(5)

        self.start_step("点击直播，进入直播间")
        self.home.init()
        self.home.open_live_room(self.device)
        time.sleep(5)
        self.home.swipe_until_not_game_room(self.device)


        living_room = LivingRoom(root=self.app)
        living_room.app.wait_for_activity(living_room.activity)

        flag = self.if_test_watching_plugin()
        self.assert_("看播插件版本号与需测试版本号不同，检查输入版本号和插件链接地址", flag == 0)
        living_room.isliving()
        self.assert_("未成功观看直播", (living_room.isWatchingLive(self.device) == 0) & (self.device.current_activity == "com.ss.android.live.host.livehostimpl.LivePlayerTransActivity"))

        self.start_step("点击关闭，退出直播间")
        living_room.swipe_to_next_room(self.device)
        time.sleep(10)
        living_room.swipe_to_next_room(self.device)
        time.sleep(10)
        living_room.quit_room()
        main_panel = StartWindow(root=self.app)
        main_panel.app.wait_for_activity(main_panel.activity)
        self.assert_("未成功退出直播",
                     self.device.current_activity == "com.ss.android.article.news.activity.MainActivity")

    def if_test_watching_plugin(self):
        # com_ss_android_liveplugin = "100000000"
        liveplugin_version = self.app.wait_plugin('com.ss.android.liveplugin', timeout=60)
        #liveresource_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)
        liveplugin_version_download = self.app.get_plugins_version("com.ss.android.liveplugin")
        #liveresource_version_download = self.app.get_plugins_version("com.ss.android.ies.live.liveresource")
        print(liveplugin_version_download)

        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已安装看播插件版本号：%s" % liveplugin_version)
        # liveresource_version = plugin_list['com.ss.android.ies.live.liveresource']


        if (liveplugin_version is not None) and (liveplugin_version_download == liveplugin_version):
            return 0
        else:
            self.log_debug("需测试看播插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1

        # com_ss_android_liveplugin = os.environ.get("看播")  # 获取输入环境变量
        # self.log_info("需测试看播插件版本号：%s" % com_ss_android_liveplugin)
        # if (int(com_ss_android_liveplugin)) == (int(liveplugin_version)):
        #     self.log_info("需测试看播插件版本号和已安装看播插件版本号相同")
        #     return 0
        # else:
        #     self.log_debug("需测试看播插件版本号和已安装看播插件版本号不同")
        #     return 1

if __name__ == '__main__':
    go = WatchLiving()
    go.debug_run()

# -*- coding: utf8 -*-

from toutiaolib.testcase import TouTiaoTest, TouTiaoTestBase
from toutiaolib.app import TouTiaoApp
from toutiaolib.main import StartWindow
from toutiaolib.living_room_panel import LivingRoom
from toutiaolib.anchor_living_room import AnchorLivingRoom
import time
from webcastlib.mobile_account import MobileRequest
import os

"""
    case:关播
"""

class CloseLiving(TouTiaoTestBase):
    """关播
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'toutiao'
    tags = 'publish_check_com.ss.android.ies.live.liveresource_13'
    ip = ''
    clear_data = True

    #头条的新包安装可能需要较长时间用于下载插件，这块可考虑延长时间和参考主端工程
    def run_test(self):
        #self.device = self.acquire_device()
        self.app = TouTiaoApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        #self.home.init()
        #time.sleep(5)
        # flag = self.if_test_start_plugin()
        # self.assert_("开播插件版本号与需测试版本号不同，检查输入版本号和插件链接地址", flag == 0)

        self.start_step("登陆")
        self.home.init()
        num = self.home.log_in()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags":"toutiao_start_living"}))

        self.start_step("开播")
        self.home.open_main_page("西瓜视频")
        self.home.start_living()
        living_room = AnchorLivingRoom(root=self.app)
        self.assert_("未成功开始直播", (living_room.StartLivingSuccesful(self.device)==0) & (self.device.current_activity =="com.ss.android.live.host.livehostimpl.LiveBroadcastActivity"))

        flag = self.if_test_start_plugin()
        self.assert_("开播插件版本号与需测试版本号不同，检查输入版本号和插件链接地址", flag == 0)

        self.start_step("关播")
        living_room.ClosingLiving()
        self.assert_("未成功关闭直播", (living_room.ClosingLivingSuccesful()==0) & (self.device.current_activity =="com.ss.android.live.host.livehostimpl.LiveBroadcastActivity"))

        g = MobileRequest()
        g.release_num(tags = 13, num = num)


    def if_test_start_plugin(self):
        # com_ss_android_liveplugin = "100000000"
        liveplugin_version = self.app.wait_plugin('com.ss.android.liveplugin', timeout=60)
        liveresource_version = self.app.wait_plugin('com.ss.android.ies.live.liveresource', timeout=60)
        liveplugin_version_download = self.app.get_plugins_version("com.ss.android.liveplugin")
        liveresource_version_download = self.app.get_plugins_version("com.ss.android.ies.live.liveresource")
        print(liveplugin_version_download)
        plugin_list = self.app.get_plugin_info()
        self.log_info(plugin_list)
        # liveplugin_version = plugin_list['com.ss.android.liveplugin']
        self.log_info("已安装看播插件版本号：%s" % liveplugin_version)
        # liveresource_version = plugin_list['com.ss.android.ies.live.liveresource']
        self.log_info("已安装开播插件版本号：%s" % liveresource_version)
        if (liveplugin_version is not None) and (liveresource_version is not None) and (liveresource_version_download==liveresource_version):
            return 0
        else:
            self.log_debug("需测试看播插件版本号和已安装开播插件版本号不同或安装插件不成功")
            return 1

        # com_ss_android_ies_live_liveresource = os.environ.get("开播")  # 获取输入环境变量
        # self.log_info("需测试开播插件版本号：%s" % com_ss_android_ies_live_liveresource)
        # if (int(com_ss_android_ies_live_liveresource)) == (int(liveresource_version)):
        #     self.log_info("需测试看播插件版本号和已安装开播插件版本号相同")
        #     return 0
        # else:
        #     self.log_debug("需测试看播插件版本号和已安装开播插件版本号不同")
        #     return 1

if __name__ == '__main__':
    go = CloseLiving()
    go.debug_run()

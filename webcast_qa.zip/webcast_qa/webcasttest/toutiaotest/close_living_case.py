# -*- coding: utf8 -*-

from toutiaolib.testcase import TouTiaoTest, TouTiaoTestBase
from toutiaolib.app import TouTiaoApp
from toutiaolib.main import StartWindow
from toutiaolib.living_room_panel import LivingRoom
from toutiaolib.anchor_living_room import AnchorLivingRoom
import time
from webcastlib.mobile_account import MobileRequest

"""
    case:关播
"""

class CloseLiving(TouTiaoTestBase):
    """关播
    """
    owner = "tanjianxin"
    timeout = 1000
    app = 'xigua'
    ip = ''
    clear_data = True

    #头条的新包安装可能需要较长时间用于下载插件，这块可考虑延长时间和参考主端工程
    def run_test(self):
        #self.device = self.acquire_device()
        #self.app = TouTiaoApp(self.device)
        self.home = StartWindow(root=self.app)
        self.home.wait_for_loading()

        self.start_step("打开app-初始化")
        time.sleep(8)
        self.home.init()
        time.sleep(5)

        self.start_step("登陆")
        self.home.init()
        num = self.home.log_in()
        #self.home.log_in(self.device, self.resmgr.acquire("account", conditions={"tags":"toutiao_start_living"}))
        time.sleep(5)

        self.start_step("开播")
        self.home.open_main_page("西瓜视频")
        self.home.start_living()
        living_room = AnchorLivingRoom(root=self.app)
        self.assert_("未成功开始直播", (living_room.StartLivingSuccesful(self.device)==0) & (self.device.current_activity =="com.ss.android.live.host.livehostimpl.LiveBroadcastActivity"))

        self.start_step("关播")
        living_room.ClosingLiving()
        self.assert_("未成功关闭直播", (living_room.ClosingLivingSuccesful()==0) & (self.device.current_activity =="com.ss.android.live.host.livehostimpl.LiveBroadcastActivity"))

        g = MobileRequest()
        g.release_num(tags = 13, num = num)

if __name__ == '__main__':
    go = CloseLiving()
    go.debug_run()

# -*- coding: utf8 -*-
import os

PROJECT_NAME = "webcast"
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
INSTALLED_LIBS = ["uibase", "shoots_android"]
ANDROID_DRIVER_TYPE = ""  # if set "uia2" will use Uiautomator2 ,default is shoots-android
SHOOTS_RESOURCE_HANDLERS = ["uibase.device.DeviceHandler", "webcastlib.account.AccountHandler"]

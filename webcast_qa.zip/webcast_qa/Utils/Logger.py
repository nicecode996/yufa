# -*- coding: UTF-8 -*-

import time
import sys
import threading


Log2File = False

def ERROR(info):
    #_表示不能被调用
    _worker("%s[ERROR][%s][%s]%s"%(_now(),__FUNC__(), __thread__(),info))

def FATAL(info):
    _worker("%s[FATAL][%s][%s]%s"%(_now(),__FUNC__(),__thread__(),info))

def WARN(info):
    _worker("%s[WARN][%s][%s]%s"%(_now(),__FUNC__(),__thread__(), info))

def INFO(info):
    _worker("%s[INFO][%s][%s]%s"%(_now(),__FUNC__(),__thread__(),info))

def _worker(info):
    if Log2File is True:
        _log2File(info)
    else:
        log2stdout(info)


def log2stdout(info):
    print(info)


def _log2File(info):
    pass

def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
# Use Only For Logger
def __FUNC__():
    ss_name = sys._getframe(2).f_code.co_name
    return ss_name

def __thread__():
    return threading.currentThread().name

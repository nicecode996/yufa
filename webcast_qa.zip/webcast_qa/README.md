# Automation Quick Start
```shell
cd /path/to/your/project
pip install -r requirements.txt
```
# 功能
直播中台-抖音自动化


## Reference

Docs of shoots: https://code.byted.org/automation/shoots.git




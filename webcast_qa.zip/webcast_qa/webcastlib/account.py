# -*- coding=utf8 -*-

"""
本地账号资源池子
"""

from shoots.resource import IResourceHandler
from shoots.loader import TestLoader
from shoots.context import current_testcase
import settings
from shoots import logger
import logging
import requests
import json
import random
headers = {'Content-Type': 'application/json'}


local_account = [{"uin": str(phone_number),"password": "1234", "tags": "common"} for phone_number in range(12340868120, 12340868121)]
local_account.append({"uin": "12340868100", "password": "1234", "tags": "douyin_start_living"})
local_account.append({"uin": "12340868101", "password": "1234", "tags": "douyin_send_gift"})
local_account.append({"uin": "12340868102", "password": "1234", "tags": "douyin_follow_anchor"})

local_account.append({"uin": "12340868100", "password": "1234", "tags": "xigua_start_living"})
local_account.append({"uin": "12340868101", "password": "1234", "tags": "xigua_send_gift"})
local_account.append({"uin": "12340868102", "password": "1234", "tags": "xigua_follow_anchor"})

local_account.append({"uin": "12340868110", "password": "1234", "tags": "huoshan_start_living"})
local_account.append({"uin": "12340868111", "password": "1234", "tags": "huoshan_send_gift"})
local_account.append({"uin": "12340868112", "password": "1234", "tags": "huoshan_follow_anchor"})

local_account.append({"uin": "12340868105", "password": "1234", "tags": "toutiao_start_living"})
local_account.append({"uin": "12340868106", "password": "1234", "tags": "toutiao_send_gift"})
local_account.append({"uin": "12340868107", "password": "1234", "tags": "toutiao_follow_anchor"})

local_account.append({"uin": "12340868103", "password": "1234", "tags": "virdouyin_startlive"})


class AccountHandler(IResourceHandler):
    res_type = "account"

    def acquire(self, session, conditions={}):

        tc = current_testcase()
        #tags = set(conditions.get("tags", []))
        tags = conditions["tags"]
        if tags == "1128":
            url1 = 'https://live-ci.apps.bytedance.net/account_pool/app/1128/idle'
            r = requests.get(url1, headers=headers)  # 获取空闲账号列表
            logger.warning(r.text)
            map = json.loads(r.text)  # 把json转换成dict
            num = map["account_list"][0]["mobile"]  # 取第一个账号
            logger.warning(num)

            url2 = 'https://live-ci.apps.bytedance.net/account_pool/app/1128/allocate/'

            data_map = {}  # 定义一个字典
            data_map["mobile"] = num  # 赋值
            mobile = json.dumps(data_map)  # 解析json,把字典转换为json字符串
            byte_mobile = str.encode(mobile)  # 字符串转字节流
            q = requests.post(url2, headers=headers, data=byte_mobile)  # 分配账号
            logger.warning(q.text)
            return data_map
        '''
        for account in local_account:
            if tags == account["tags"]:
                logger.info("account %s" % account)
                return account'''

    def release(self, session, conditions={}):
        tc = current_testcase()
        #tags = set(conditions.get("tags", []))
        tags = conditions["tags"]
        data_map = {}  # 定义一个字典
        data_map["mobile"] = tags  # 赋值
        mobile = json.dumps(data_map)  # 解析json,把字典转换为json字符串
        byte_mobile = str.encode(mobile)  # 字符串转字节流
        if tags == "1128":
            url3 = 'https://live-ci.apps.bytedance.net/account_pool/app/1128/free'
            p = requests.post(url3, headers=headers, data=byte_mobile)  # 释放账号
            logger.warning(p.text)

    def get_num(self, tags):
        if tags == '1128':
            url1 = 'https://live-ci.apps.bytedance.net/account_pool/app/1128/idle'
            r = requests.get(url1, headers=headers)  # 获取空闲账号列表
            logger.warning(r.text)
            map = json.loads(r.text)  # 把json转换成dict
            num = map["account_list"][0]["mobile"]  # 取第一个账号
            logger.warning(num)

            url2 = 'https://live-ci.apps.bytedance.net/account_pool/app/1128/allocate/'

            data_map = {}  # 定义一个字典
            data_map["mobile"] = num  # 赋值
            mobile = json.dumps(data_map)  # 解析json,把字典转换为json字符串
            byte_mobile = str.encode(mobile)  # 字符串转字节流
            q = requests.post(url2, headers=headers, data=byte_mobile)  # 分配账号
            logger.warning(q.text)
            return data_map


    def query(self, conditions={}):
        pass

    def create_session(self, testcase):
        pass

    def request(self, path, params):
        pass

    def destroy_session(self, session):
        pass

    def release(self, account):
        pass


if __name__ == "__main__":
    pass

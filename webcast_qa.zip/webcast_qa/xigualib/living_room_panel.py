# -*- coding: utf8 -*-
"""
直播间
"""

from shoots_android.control import *
from uibase.upath import *

class LivingRoom(Window):
    """
    live room
    """
    window_spec = {"activity": "com.ixigua.feature.live.LivePlayerActivity"}

    def get_locators(self):
        return {
            "主播id": {"type": Control, "path": UPath(id_ == "user_name")},
            "主播id_170": {"type": Control, "path": UPath(id_ == "user_role_open_url_tag")},
            "媒体直播间主播id": {"type": Control, "path": UPath(id_ == "media_anchor_name")},
            "关闭": {"type": Control, "path": UPath(id_ == "close_btn_back")},
            "关闭1": {"type": Control, "path": UPath(id_ == "close_btn")},
            "关注": {"type": Control, "path": UPath(id_ == "follow", text_ == "关注")},
            "直播已结束": {"type": Control, "path": UPath(id_ == "ttlive_tv_end_label", text_ == "直播已结束")},
            "您正在直播中，是否继续直播？": {"type": Control, "path": UPath(text_ == "您正在直播中，是否继续直播？")},
            "结束直播": {"type": Control, "path": UPath(text_ == "结束直播")}
        }
    def isliving(self):
        if self["您正在直播中，是否继续直播？"].existing:
            self["结束直播"].click()
        time.sleep(10)

    def ifLivingFinish(self):
        if self["直播已结束"].existing:
            return 1
        else:
            return 0

    def isWatchingLive(self, device):
        if device.current_activity == "com.ixigua.feature.live.LivePlayerActivity" or self["主播id_170"].visible:
            return 0
        if device.current_activity == "com.ixigua.feature.live.LivePlayerActivity" or self["主播id"].visible:
            return 0
        elif device.current_activity == "com.ixigua.feature.live.LivePlayerActivity" or self["媒体直播间主播id"].visible:
            return 0
        else:
            return 1

    def swipe_to_next_room(self,device):
        old_anchor_name = self.get_anchor_name()
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, device.screen_rect.height // 2,
            device.screen_rect.width // 2, device.screen_rect.height // 20))
        time.sleep(5)
        if self.get_anchor_name() != old_anchor_name:
            return 0
        else:
            return 1

    def get_anchor_name(self):
        if self["主播id"].existing:
            print(self["主播id"].text)
            return self['主播id'].text
        elif self["媒体直播间主播id"].existing:
            print(self["媒体直播间主播id"].text)
            return self['媒体直播间主播id'].text

    def quit_room(self,device):

      while not device.current_activity == "com.ss.android.article.video.activity.SplashActivity":
         #版本更新之后165
            if self["关闭1"].wait_for_visible(raise_error=False):
                self["关闭1"].click()
                time.sleep(5)
        #更新之前
            elif self["关闭"].existing:
                self["关闭"].click()
                time.sleep(5)

    def follow_anchor(self,device):
        if self["关注"].visible:
            self["关注"].click()
            time.sleep(5)
            if not self["关注"].visible:
                return 0
        else:
            while not self["关注"].visible:
                self.swipe_to_next_room(device)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
                if not self["关注"].visible:
                    return 0
            else:
                return 1


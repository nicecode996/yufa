# -*- coding: utf8 -*-
"""
直播开始前准备
"""

from shoots_android.control import *
from uibase.upath import *
from xigualib.preview_start_living import PreviewStartLiving

class BeforeStartLiving(Window):
    """
    before start live room
    """
    window_spec = {"activity": "com.ixigua.feature.live.LiveBroadcastBeforeActivity"}

    def get_locators(self):
        return {
            "下一步": {"type": Control, "path": UPath(id_ == "startlive_preview_btn")},
            "添加分类标签":{"type": Control, "path": UPath(id_ == "startlive_label_choose", text_ == "添加分类标签")},
            "分类标签":{"type": Control, "path": UPath(id_ == "tv_category_name", index=0)},
            "直播意外中断了，是否继续直播":{"type": Control, "path": UPath(id_ == "alertTitle", text_ == "直播意外中断了，是否继续直播")},
            "取消":{"type": Control, "path": UPath(id_ == "button2", text_ == "取消")},
            "开始视频直播":{"type": Control, "path": UPath(id_ == "bt_start_live", text_ == "开始视频直播")},
            "选择分类": {"type": Control, "path": UPath(id_ == "category_selected", text_ == "选择分类", index=1)},
            "户外打野": {"type": Control, "path": UPath(id_ == "category_name", text_ == "户外打野")}

        }

    def start_living(self):
        if self["直播意外中断了，是否继续直播"].existing:
            self["取消"].click()
            time.sleep(3)
        if self["选择分类"].wait_for_visible(raise_error=False):

            self["选择分类"].click()
            self["户外打野"].wait_for_visible(raise_error=False)
            self["户外打野"].click()
        self["开始视频直播"].wait_for_visible(raise_error=False)
        self["开始视频直播"].click()
        # preiew_panel = PreviewStartLiving(root=self.app)
        # preiew_panel.start_living()


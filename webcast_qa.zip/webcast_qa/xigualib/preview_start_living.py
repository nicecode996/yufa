# -*- coding: utf8 -*-
"""
开始直播
"""

from shoots_android.control import *
from uibase.upath import *

class PreviewStartLiving(Window):
    """
     before start live room
     """
    window_spec = {"activity": "com.ixigua.feature.live.LiveBroadcastPreviewActivity"}

    def get_locators(self):
        return {
            "开始视频直播": {"type": Control, "path": UPath(id_ == "fragment_record", text_ == "开始视频直播")}
        }

    def start_living(self):
        self["开始视频直播"].click()
        #time.sleep(10)

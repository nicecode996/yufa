# -*- coding: UTF-8 -*-
import time
from shoots_android.control import *
from uibase.upath import *


class SplashPanel(Window):
    """启动闪屏
    """
    window_spec = {"activity": 'com.ss.android.article.news.activity.SplashBadgeActivity',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {'我知道了': {'type': Control, 'path': UPath(text_ == '我知道了')}, }

    def agree(self):
        if self["我知道了"].wait_for_existing(timeout=3, interval=0.5, raise_error=False):
            self["我知道了"].click()
            return True
        return False

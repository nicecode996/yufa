# -*- coding: utf8 -*-
"""
游戏媒体直播间
"""

from shoots_android.control import *
from uibase.upath import *

class GameLivingRoom(Window):
    """
    game live room
    """

    window_spec = {"activity": "com.ss.android.live.host.livehostimpl.LivePlayerActivity"}

    def get_locators(self):
        return {
            "主播id": {"type": Control, "path": UPath(id_ == "live_broadcaster_name")},
            "返回": {"type": Control, "path": UPath(id_ == "iv_back")}
        }

    def quit_game_room(self):
        self["返回"].click()
        time.sleep(2)
        if self["返回"].existing:
            self["返回"].click()
            time.sleep(5)

# -*- coding: utf8 -*-
"""
直播间
"""

from shoots_android.control import *
from uibase.upath import *

class LivingRoom(Window):
    """
    live room
    """

    window_spec = {"activity": "com.ss.android.live.host.livehostimpl.LivePlayerTransActivity"}

    def get_locators(self):
        return {
            "主播id": {"type": Control, "path": UPath(id_ == "user_name")},#ab实验
            "主播idb": {"type": Control, "path": UPath(id_ == "user_stub")},
            "主播id_170": {"type": Control, "path": UPath(id_ == "user_role_open_url_tag")},
            "媒体直播间主播id": {"type": Control, "path": UPath(id_ == "media_anchor_name")},
            "动作按钮":{"type":Control, "path": UPath(id_ == "action_container")},
            "关闭": {"type": Control, "root":"动作按钮","path": UPath(id_ == "close_btn_back")},
            "关闭a": {"type": Control, "root":"动作按钮","path": UPath(id_ == "close_btn")},
            "关注": {"type": Control, "path": UPath(id_ == "follow", text_ == "关注")},
            "您正在直播中，是否继续直播？": {"type": Control, "path": UPath(text_ == "您正在直播中，是否继续直播？")},
            "结束直播": {"type": Control, "path": UPath(text_ == "结束直播")},
        }
    def get_window(self):
        return self.window_spec["activity"]


    def isliving(self):
        if self["您正在直播中，是否继续直播？"].existing:
            self["结束直播"].click()
        time.sleep(10)

    def isWatchingLive(self, device):
        time.sleep(5)
        if self["主播id_170"].existing or self["主播id"].existing or self["媒体直播间主播id"].existing:
            return 0
        elif self["关闭"].existing or self["关闭a"].existing:
            return 0
        else:
            time.sleep(10)
            if self["主播id_170"].existing or self["主播id"].existing or self["媒体直播间主播id"].existing:
                return 0
            else:
                return 1

    def quit_room(self):
        if self["关闭"].existing:
            self["关闭"].click()
            time.sleep(5)
        elif self["关闭a"].existing:
            self["关闭a"].click()
            time.sleep(5)



    def swipe_to_next_room(self,device):
        old_anchor_name = self.get_anchor_name()
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, device.screen_rect.height // 2,
            device.screen_rect.width // 2, device.screen_rect.height // 30))
        time.sleep(5)
        if self.get_anchor_name() != old_anchor_name:
            return 0
        else:
            return 1

    def swipe(self, x_direction=0, y_direction=1, swipe_coefficient=3):
        '''滑动

        :param x_direction: 大于0向左，小于0向右
        :param y_direction: 大于0向上，小于0向下
        后续会支持斜着滑动

        :param coefficient:滑动系数 ,决定滑动距离，系数允许范围（2，8]
        '''

        if swipe_coefficient <= 2 or swipe_coefficient > 8:
            raise ValueError("coefficient range is （2，8]")

        rect = self.ensure_visible()
        if y_direction > 0 and x_direction == 0:
            x1 = x2 = rect.left + rect.width // 2
            y1 = rect.top + rect.height * (swipe_coefficient - 1) // swipe_coefficient
            y2 = rect.top + rect.height // swipe_coefficient
        elif y_direction < 0 and x_direction == 0:
            x1 = x2 = rect.left + rect.width // 2
            y1 = rect.top + rect.height // swipe_coefficient
            y2 = rect.top + rect.height * (swipe_coefficient - 1) // swipe_coefficient
        elif x_direction > 0 and y_direction == 0:
            y1 = y2 = rect.top + rect.height // 2
            x1 = rect.left + rect.width * (swipe_coefficient - 1) // swipe_coefficient
            x2 = rect.left + rect.width // swipe_coefficient
        elif x_direction < 0 and y_direction == 0:
            y1 = y2 = rect.top + rect.height // 2
            x1 = rect.left + rect.width // swipe_coefficient
            x2 = rect.left + rect.width * (swipe_coefficient - 1) // swipe_coefficient
        else:
            raise ValueError("not support this direction x {}  y{}".format(x_direction, y_direction))

        self._driver.drag(self.id, x1, y1, x2, y2)
        time.sleep(1)

    def drag(self, to_x, to_y, offset_x=0, offset_y=0, duration=None, count=None):
        rect = self.ensure_visible()
        center = rect.center
        x = float(center[0] + offset_x)
        y = float(center[1] + offset_y)
        return self._driver.drag(self.id,
                                 from_x=x,
                                 from_y=y,
                                 to_x=float(to_x),
                                 to_y=float(to_y),
                                 duration=duration,
                                 count=count)

    def swipe_for_change_room(self,y_direction=1,swipe_coefficient=3):
        old_anchor_name = self.get_anchor_name()
        self.swipe(y_direction=y_direction,
                   swipe_coefficient=swipe_coefficient)
        time.sleep(5)
        self.swipe(y_direction=y_direction,
                   swipe_coefficient=swipe_coefficient)
        time.sleep(5)
        self.swipe(y_direction=y_direction,
                   swipe_coefficient=swipe_coefficient)
        time.sleep(5)
        self.swipe(y_direction=y_direction,
                   swipe_coefficient=swipe_coefficient)
        time.sleep(5)
        if self.get_anchor_name() != old_anchor_name:
            return 0
        else:
            return 1

    def get_anchor_name(self):
        if self["主播id"].existing:
            print(self["主播id"].text)
            return self['主播id'].text
        elif self["媒体直播间主播id"].existing:
            print(self["媒体直播间主播id"].text)
            return self['媒体直播间主播id'].text
        elif self["主播idb"].existing:
            print(self["主播idb"].text)
            return self['主播idb'].text
        elif self["主播id_170"].existing:
            print(self["主播id_170"].text)
            return self['主播id_170'].text



    def follow_anchor(self,device):
        if self["关注"].visible:
            self["关注"].click()
            time.sleep(5)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
            if not self["关注"].visible:
                return 0
        elif self["关注"].visible:
            self["关注"].click()
            time.sleep(5)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
            if not self["关注"].visible:
                return 0
        else:
            while not self["关注"].visible:
                self.swipe_to_next_room(device)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(5)
                if self["关注"].visible:
                    self["关注"].click()
                    time.sleep(5)
                if self["关注"].visible:
                    self["关注"].click()
                    time.sleep(5)
                if not self["关注"].visible:
                    return 0
            else:
                return 1

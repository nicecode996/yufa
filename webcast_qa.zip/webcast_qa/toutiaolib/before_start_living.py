# -*- coding: utf8 -*-
"""
直播开始前准备
"""

from shoots_android.control import *
from uibase.upath import *
from toutiaolib.preview_start_living import PreviewStartLiving

class BeforeStartLiving(Window):
    """
    before start live room
    """
    window_spec = {"activity": "com.ss.android.live.host.livehostimpl.LiveBroadcastBeforeActivity"}

    def get_locators(self):
        return {
            "下一步": {"type": Control, "path": UPath(id_ == "startlive_preview_btn")},
            "直播间标题":{"type": Control, "path": UPath(id_ == "startlive_title_edit")},
            "添加分类标签":{"type": Control, "path": UPath(id_ == "startlive_label_choose", text_ == "添加分类标签")},
            "分类标签":{"type": Control, "path": UPath(id_ == "tv_category_name", index=0)},
            "横版封面": {"type": Control, "path": UPath(id_ == "startlive_cover", index=0)},
            "竖版封面": {"type": Control, "path": UPath(id_ == "startlive_cover", index=1)},
            "拍照": {"type": Control, "path": UPath(id_ == "camera_text")},
            "直播意外中断了，是否继续直播":{"type": Control, "path": UPath(id_ == "alertTitle", text_ == "直播意外中断了，是否继续直播")},
            "取消":{"type": Control, "path": UPath(id_ == "button2", text_ == "取消")},
            "开始视频直播": {"type": Control, "path": UPath(id_ == "bt_start_live", text_ == "开始视频直播")},
            "选择分类": {"type": Control, "path": UPath(id_ == "category_selected", text_ == "选择分类", index=1)},
            "户外打野": {"type": Control, "path": UPath(id_ == "category_name", text_ == "户外打野")},
            "户外打野_170": {"type": Control, "path": UPath(id_ == "cards_container", text_ == "户外打野")},
        }

    def start_living(self):
        if self["直播意外中断了，是否继续直播"].existing:
            self["取消"].click()
            time.sleep(3)
        #if self["选择分类"].existing:
        self["选择分类"].click()
        time.sleep(3)

        if self["户外打野_170"].wait_for_visible(raise_error=False):
            self["户外打野_170"].click()
        else:
            self["户外打野"].click()


        time.sleep(6)
        self["开始视频直播"].wait_for_visible()
        print("执行了点击开播")
        if self["开始视频直播"].wait_for_visible(timeout=40,raise_error=False):
            self["开始视频直播"].click()
            time.sleep(6)
            #点击失败重试
            if self["开始视频直播"].wait_for_visible(raise_error=False):
                self["开始视频直播"].click()
                time.sleep(6)
        # preiew_panel = PreviewStartLiving(root=self.app)
        # preiew_panel.start_living()


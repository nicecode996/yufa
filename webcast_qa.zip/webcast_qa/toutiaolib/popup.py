# -*- coding: UTF-8 -*-
from shoots_android.control import *
from uibase.upath import *


class UpgradePopup(Window):
    '''
    升级弹窗页面
    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "以后再说": {'type': TextView, 'path': UPath(id_ == "later_btn", visible_ == True, index=0)},
        }

    def handler(self):
        if self['以后再说'].existing:
            self['以后再说'].click()
            time.sleep(1)
            return not self['以后再说'].existing
        return False


class ClosedbetaPopup(Window):
    '''
    升级弹窗页面
    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "关闭员工内测按钮": {'type': TextView, 'path': UPath(id_ == "update_check_cancel_btn", visible_ == True, index=0)},
        }

    def handler(self):
        if self['关闭员工内测按钮'].existing:
            self['关闭员工内测按钮'].click()
            time.sleep(1)
            return not self['关闭员工内测按钮'].existing
        return False


class AccountUpgradePopup(Window):
    '''
    升级弹窗页面
    '''
    window_spec = {"activity": '',  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {
            "升级": {'type': TextView, 'path': UPath(visible_ == True, text_ == "升级")},
        }

    def handler(self):
        if self['升级'].existing:
            self['升级'].click()
            time.sleep(1)
            return not self['升级'].existing
        return False


class BrowserLocationPopup(Window):
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "允许": {'type': TextView, 'path': UPath(id_ == "button1", visible_ == True, text_ == "允许")},
        }

    def handler(self):
        if self['允许'].existing:
            self['允许'].click()
            time.sleep(1)
            return not self['允许'].existing
        return False


class MarketFeedbackPopup(Window):
    """反馈弹窗
    """
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "关闭": {'type': Control, 'path': UPath(id_ == "market_feedback_dialog_close", visible_ == True)},
        }

    def handler(self):
        if self['关闭'].existing:
            self['关闭'].click()
            time.sleep(1)
            return not self['关闭'].existing
        return False


class RealTimePushPopup(Window):
    """即时推送弹窗
    """
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "忽略": {'type': Control, 'path': UPath(id_ == "btn_left", text_ == '忽略', visible_ == True)},
        }

    def handler(self):
        if self['忽略'].existing:
            self['忽略'].click()
            time.sleep(1)
            return not self['忽略'].existing
        return False


class AudioFloatingPopup(Window):
    """音频浮窗
    """
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "音频浮窗标题": {'type': Control, 'path': UPath(id_ == "tv_title", text_ == '开启音频浮窗功能', visible_ == True)},
            "取消": {'type': Control, 'path': UPath(id_ == "tv_cancel", text_ == '取消', visible_ == True)},
        }

    def handler(self):
        if self['音频浮窗标题'].existing:
            self['取消'].click()
            time.sleep(1)
            return not self['音频浮窗标题'].existing
        return False


class AudioFinishPayPopup(Window):
    """音频试听结束，购买专栏弹框
    """
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "试听结束": {'type': Control, 'path': UPath(id_ == "cover_course_wrapper", visible_ == True)},
            "购买专栏": {'type': Control, 'path': UPath(id_ == "btn_container", visible_ == True)},
        }

    def handler(self):
        if self['试听结束'].existing:
            self['购买专栏'].click()
            time.sleep(1)
            return True
        return False

class SmoothModePopup(Window):
    """中低端机上的流畅模式弹窗弹窗
    """
    window_spec = {"activity": '',
                   "process_name": None}

    def get_locators(self):
        return {
            "暂不开启": {'type': Control, 'path': UPath(id_ == "dialog_no_btn", visible_ == True)},
        }

    def handler(self):
        if self['暂不开启'].existing:
            self['暂不开启'].click()
            time.sleep(1)
            return not self['暂不开启'].existing
        return False

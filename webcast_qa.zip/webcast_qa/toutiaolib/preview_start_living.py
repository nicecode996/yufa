# -*- coding: utf8 -*-
"""
开始直播
"""

from shoots_android.control import *
from uibase.upath import *

class PreviewStartLiving(Window):
    """
     before start live room
     """
    window_spec = {"activity": "com.ss.android.live.host.livehostimpl.LiveBroadcastPreviewActivity"}

    def get_locators(self):
        return {
            "开始视频直播": {"type": Control, "path": UPath(id_ == "fragment_record", text_ == "开始视频直播")}
        }

    def start_living(self):
        if self["开始视频直播"].wait_for_visible(timeout=20, raise_error=False):
            while self["开始视频直播"].existing:
                self["开始视频直播"].click()
                time.sleep(20)


# -*- coding: utf8 -*-
"""anchor living room page
"""

from shoots_android.control import *
from uibase.upath import *

class AnchorLivingRoom(Window):
    """start window
    """
    window_spec = {"activity": "com.ss.android.live.host.livehostimpl.LiveBroadcastActivity"}

    def get_locators(self):
        return {
            "主播信息":{"type": Control, "path": UPath(id_ == "anchor_info_container")},
            "关闭":{"type": Control, "path": UPath(id_ == "close")},
            "提示":{"type": Control, "path": UPath(id_ == "live_dialog_title", text_ == "提示")},
            "确定":{"type": Control, "path": UPath(id_ == "live_dialog_btn_1", text_ == "确定")},
            "关播按钮": {"type": Control, "root": "动作按钮", "path": UPath(index=4)},
            "结束页关闭按钮":{"type": Control, "path": UPath(id_ == "back_to_main")},
            "动作按钮": {"type": Control, "path": UPath(id_ == "action_container")},
            "页面中间": {"type": Control, "path": UPath(id_ == 'barrage_view')},
            "更多面板": {"type": Control, "path": UPath(id_ == "grid_layout")},
            "礼物": {"type":Control, "root": "更多面板", "path": UPath(text_ == "礼物")},
            "礼物列表": {"type": Control, "path": UPath(id_ == 'list')},
            "礼物a": {"type": Control, "root": "礼物列表", "path": UPath(index=2)},
            "更多": {"type": Control, "root": "动作按钮", "path": UPath(index=5)},
            "小礼物托盘": {"type": Control, "path": UPath(id_ == "base_gift_view")},
            "礼物面板关闭按钮": {"type": Control, "path": UPath(id_ == "close_btn_view")},
            "大礼物托盘容器":{"type": Control, "path": UPath(id_ == "user_view_container")},
            "大礼物托盘": {"type": Control, "root": "大礼物托盘容器", "path": UPath(id_ == "user_view")}
        }

    def StartLivingSuccesful(self,device):
        time.sleep(10)
        #print(self["主播id"].text)
        if self["主播信息"].visible:
            return 0
        else:
            return 1

    def ClosingLiving(self):
        while self["关播按钮"].existing:
            self["关播按钮"].click()
            time.sleep(2)
            if self["提示"].existing:
                self["确定"].click()
            time.sleep(6)

    def ClosingLivingSuccesful(self):
        if self["结束页关闭按钮"].visible:
            return 0
        else:
            return 1

    def SendGifta(self):
        try:
            self["更多"].click()
            time.sleep(2)
            if self["更多面板"].wait_for_visible(timeout=10, raise_error=False):
                print("打开更多面板")
            else:
                self["页面中间"].click()
                time.sleep(5)
                self["更多"].click()
                time.sleep(5)
        except:
            self["页面中间"].click()
            time.sleep(5)
            self["更多"].click()
            time.sleep(2)
            self["更多面板"].wait_for_visible(timeout=10, raise_error=False)

        if self["礼物"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物"].click()
            time.sleep(5)
        if self["礼物a"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物a"].click()
            self["礼物a"].click()
        for _ in Retry(timeout=20, interval=0.2, raise_error=False):
            if self["小礼物托盘"].existing:
                if self["小礼物托盘"].visible:
                    return 0
            if self["大礼物托盘"].existing:
                if self["大礼物托盘"].visible:
                    return 0
        return 1



    def sendGiftSuccesful(self):
        for _ in Retry(timeout=10, interval=0.2, raise_error=False):
            if self["小礼物托盘"].existing or self["大礼物托盘"].existing:
                time.sleep(10)
                return 0
        else:
            return 1


    def closeGiftpanel(self):
        if self["礼物面板关闭按钮"].existing:
            self["礼物面板关闭按钮"].click()
            self["礼物面板关闭按钮"].wait_for_invisible()

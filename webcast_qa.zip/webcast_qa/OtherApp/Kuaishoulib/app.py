# -*- coding:utf-8 _*-

from shoots_android.androidapp import AccessibilityApp





class KuaishouApp(AccessibilityApp):
    app_spec = {
        "package_name": "com.smile.gifmaker",  # 被测app的包名
        "init_device": True,
        "process_name": "",
        "start_activity": "",
        "grant_all_permissions": True,
        "clear_data": False,
        "kill_process": True
    }

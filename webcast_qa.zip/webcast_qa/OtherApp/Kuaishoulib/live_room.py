# -*- coding:utf-8 _*-

from shoots_android.control import Window, Control, TextView,ControlList
from shoots_android.upath import UPath, desc_, id_,text_
from shoots import logger
import time
from OtherApp.Kuaishoulib.customize_object.rank_people import rankPeople

class LiveRoom(Window):
    """直播间
    """
    window_spec = {"activity": 'com.yxcorp.gifshow.detail.PhotoDetailActivity'}

    def get_locators(self):
        return {

            "小时榜": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/live_district_rank_pendant_view')},
            "全国榜名单": {'type': ChatList, 'path': UPath(id_ == 'com.smile.gifmaker:id/recycler_view')},
            "全国榜": {'type': TextView, 'path': UPath(text_=='全国榜')},
            "榜底部": {'type': TextView, 'path': UPath(text_=='本小时榜单前100')},

        }



    def search_list(self):
        self["小时榜"].wait_for_visible()
        self["小时榜"].click()

        #检测是小时榜是否点击成功
        if not self["全国榜"].wait_for_visible(timeout=10,raise_error=False):
            logger.warning("再次点击小时榜")
            self["小时榜"].click()
        #切换至全国榜
        self["全国榜"].click()

        #获取全国榜名单
        num = 0  #统计记录的榜单人数
        result = ""
        while num < 100:
            chat_list = self["全国榜名单"]
            items = chat_list.items()
            print("第%s次获取controllist"%num)
            print("获取controllist之后")
            print(items)
            temp = 0  #统计需要滑动页面的时机
            index = 0
            lenth = len(items)
            while index<lenth:
            #for index in range(len(items)):
                print("index为%s"%index)
                conversation = items[index]
                if conversation.is_visible():
                    print("检测不到组件切换")
                    if index == len(items)-1:
                        #未到榜单
                        self.swipe(x_direction=0, y_direction=1, swipe_coefficient=3)
                        break
                    else:
                        index +=1
                        continue

                temps = conversation.get_rank
                if num!= 0 and int(temps) <= num:
                    print("当前temps为%s,向下滑动"%temps)
                    print("当前num为%s 向下滑动"%num)
                    if index == len(items)-1:
                        self.swipe(x_direction=0, y_direction=1, swipe_coefficient=3.3)
                        break
                    else:
                        cha = num-int(temps)
                        if index+cha >= len(items)-1:
                            self.swipe(x_direction=0, y_direction=1, swipe_coefficient=3.3)
                            break
                        else:
                            index = index + cha + 1
                            continue

                elif num+1 <int(temps):
                    print("向上滑动")
                    print("当前temps为%s,向上滑动" % temps)
                    print("当前num为%s 向上滑动" % num)
                    self.swipe(x_direction=0, y_direction=-1, swipe_coefficient=2.1)
                    break

                num = int(temps)

                print("多少个元素了%s"%num)

                result =result+"排名: "+conversation.get_rank+"  姓名: "+conversation.get_name+"   流量: "+conversation.get_coin+"\n"
                #logger.info(result)
                # logger.info("排名:%s,  姓名：%s, 流量：%s "%(conversation.get_rank,conversation.get_name,conversation.get_coin))
                # print(conversation.get_coin)
                # print(conversation.get_name)
                index +=1
            time.sleep(5)

        logger.info(result)





class Conversation(Control):

    def get_locators(self):
        return {
            "rank": {"path": UPath(id_ == "com.smile.gifmaker:id/live_hourly_rank_user_rank")},
            "avatar": {"path": UPath(id_ == "com.smile.gifmaker:id/live_hourly_rank_user_avatar")},
            "username": {"path": UPath(id_ == "com.smile.gifmaker:id/live_hourly_rank_user_name",index=0)},
            "container": {"path": UPath(id_ == "com.smile.gifmaker:id/live_hourly_rank_user_coin_and_pk_container")},
            "coin": {"root": "container","path": UPath(id_ == "com.smile.gifmaker:id/live_hourly_rank_user_coin")},
        }

    @property
    def get_rank(self):
        return self.rank.text
        # if self.rank.wait_for_visible(timeout=2,raise_error=False):
        #     return self.rank.text
        # else:
        #     logger.warning("向下滑动")
        #     liveRoom = LiveRoom(root=self.app)
        #     liveRoom.scroll_high()
        #
        #     if self.rank.wait_for_visible(timeout=2, raise_error=False):
        #         logger.warning("滑动后获取到了排名信息")
        #          return self.rank.text
    @property
    def get_name(self):
        return self.username.text

    @property
    def get_coin(self):
        return self.coin.text

    def is_visible(self):
        if self.rank.wait_for_visible(timeout=2, raise_error=False) and self.username.wait_for_visible(timeout=2, raise_error=False) and self.coin.wait_for_visible(timeout=2, raise_error=False):
            return False
        else:
            return True


class ChatList(ControlList):
    """contact list
    """
    elem_class = Conversation

    def open_chat(self, chat_name):
        for chat in self.items():
            if chat.chat_name == chat_name:
                chat.click()
                break
        else:
            raise RuntimeError("chat_name=%s not found" % chat_name)

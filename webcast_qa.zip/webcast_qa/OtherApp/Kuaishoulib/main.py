# -*- coding:utf-8 _*-

from shoots_android.control import Window, Control, TextView
from shoots_android.upath import UPath, desc_, id_,text_
from shoots import logger
import time
from shoots_android.androidapp import AccessibilityApp
from shoots_android.androidtestbase import AndroidTestBase
from byted_cv.ocr_helper import find_pic, click_pic
from settings import PROJECT_ROOT
from shoots.retry import Retry
from OtherApp.Kuaishoulib.live_room import LiveRoom
import os

resoureces_path = PROJECT_ROOT + "/resources/images/"




class MainPanel(Window):
    """快手首页
    """
    window_spec = {"activity": 'com.yxcorp.gifshow.HomeActivity'}

    def get_locators(self):
        return {

            "头像/登录": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/left_btn')},
            "直播广场1": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/container',index=2)},
            "直播广场": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/container',index=3)},
            "手机号登录": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/password_login_title',text_=="手机号登录")},
            "手机号": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/phone_et')},
            "密码": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/password_et')},
            "验证码/密码登录": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/login_mode_switcher')},
            "登录": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/confirm_btn')},
            "个人信息展示": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/tab_avatar_wrapper')},
            "个人头像": {'type': TextView, 'path': UPath(id_ == 'com.smile.gifmaker:id/tab_avatar')},

        }
    def is_login(self):

        self["头像/登录"].wait_for_visible()
        if self["头像/登录"].text == "登录":
            return False
        else:
            return True
    def login(self):

        if self.is_login():
            logger.info("已经登陆")
            return
        else:
            self["头像/登录"].click()
            #检测是否进入到了登录界面
            if not self["手机号登录"].wait_for_visible(timeout=6,raise_error=False):
                logger.info("再次点击登录")
                self["头像/登录"].click()
        #输入手机号和密码

        self["手机号"].text="19913148542"
        #切换为密码登陆
        num = self["验证码/密码登录"].text
        if num == "密码登录":
            self["验证码/密码登录"].click()
            time.sleep(5)
            #再次检测确认
            if self["验证码/密码登录"].text == "密码登录":
                self["验证码/密码登录"].click()

        self["密码"].text="Mx995210"
        self["登录"].click()
        time.sleep(7)
        #确保登录成功
        if self["登录"].wait_for_visible(timeout=15,raise_error=False):
            self["登录"]


    def enter_live(self,device):
        if not self.is_login():
            logger.warning("未登陆")
            self.is_login()
        time.sleep(10)#等待页面稳定
        logger.warning("点击头像之前")
        time.sleep(5)
        print(self["头像/登录"].wait_for_visible(timeout=10,raise_error=False))
        self["头像/登录"].highlight()
        time.sleep(6)
        for _ in Retry(limit=10, interval=3, raise_error=False):
            if self["头像/登录"].wait_for_visible(timeout=3,raise_error=False):
                self["头像/登录"].click()
        # 进入含有直播广场的界面
        # if find_pic(driver=device, target_path=os.path.join(resoureces_path, 'myself.png')):
        #     logger.warning("图像点击之后")
        #     click_pic(driver=device, target_path=os.path.join(resoureces_path, 'myself.png'))
        logger.warning("点击头像之后")


        temp = 0 #超时次数
        #print(self["个人信息展示"].wait_for_visible(timeout=10,raise_error=False) and self["个人头像"].wait_for_visible(timeout=10,raise_error=False))
        while not (self["个人信息展示"].wait_for_visible(timeout=10,raise_error=False) and self["个人头像"].wait_for_visible(timeout=10,raise_error=False)):
            logger.warning("再次点击进入我的页面")
            self["头像/登录"].click()
            time.sleep(4)
            temp += 1
            if temp > 5:
                logger.warning("无法进入我的主页")
                break
        #print(self["直播广场"].wait_for_visible(timeout=10,raise_error=False))
        #检测是否进入我的页面
        if not self["直播广场"].wait_for_visible(timeout=10,raise_error=False):
            logger.warning("再次点击进入我的页面")
            self["头像/登录"].click()
            time.sleep(4)

        time.sleep(4)
        #进入直播广场
        self["直播广场"].click()
        time.sleep(10)
        liveRoom = LiveRoom(root=self.app)
        if liveRoom.window_spec["activity"] != self.app.current_activity:
            self["头像/登录"].highlight()
            time.sleep(6)
            self["头像/登录"].click()
            time.sleep(5)

            self["直播广场1"].click()
            time.sleep(10)

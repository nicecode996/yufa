
class rankPeople:

    def __init__(self,rank,name,flow):
        self.rank = rank
        self.name = rank
        self.flow = flow


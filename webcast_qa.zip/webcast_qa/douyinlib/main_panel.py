# -*- coding: utf8 -*-
"""main page
"""
from shoots_android.control import *
from uibase.upath import *
from douyinlib.common.setting_panel import SettingPanel
import logging
from douyinlib.common.address_book_friends_panel import  FriendPanel
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.login_panel_high import LoginPanelhigh

class MainWindow(Window):
    """start window
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.main.MainActivity"}

    def get_locators(self):
        return {
            "页面": {"type": ScrollView, "path": UPath(id_ == "content", index=0)},
            "首页": {"type": Control, "path": UPath(text_ == "首页")},
            "同城": {"type": Control, "path": UPath(text_ == "同城")},
            "拍摄按钮": {"type": Control, "path": UPath(id_ == "tab_refresh", desc_ == "拍摄，按钮")},
            "拍摄按钮插件版": {"type": Control, "path": UPath(id_ == "dj8", desc_ == "拍摄，按钮")},
            "消息": {"type": Control, "path": UPath(text_ == "消息")},
            "我": {"type": Control, "path": UPath(text_ == "我")},
            #   直接从Live中进入直播间
            "LIVE": {"type": Control, "path": UPath(id_ == "iv_btn_story_switch")},
            #   可以单击主播头像进入直播间
            "用户头像": {"type": Control, "path": UPath(id_ == "user_avatar")},
            # 初始化
            "个人信息保护指引": {"type": Control, "path": UPath(id_ == "title", text_ == "个人信息保护指引")},
            "好的": {"type": Control, "path": UPath(id_ == "confirm", text_ == "好的")},
            "好的插件版": {"type": Control, "path": UPath(id_ == "a1p", text_ == "好的")},
            "同意": {"type": Control, "path": UPath(id_ == "confirm", text_ == "同意")},#v1260版本
            "我知道了": {"type": Control, "path": UPath(id_ == "tv_right", text_ == "我知道了")},
            "设置": {"type": Control, "path": UPath(id_ == "more_btn",visible_==True)},
            "DebugTest": {"type": Control, "path": UPath(text_ == "Debug Test")},
            "设置页的设置": {"type": Control, "path": UPath(text_ == "设置")},
            "发现通讯录好友": {"type": Control, "path": UPath(id_ == "title", text_ == "发现通讯录好友")},
            "访问位置请求": {"type": Control, "path": UPath(id_ == "tv_title", text_ == "允许访问你的'位置'？")},
            "允许访问位置": {"type": Control, "path": UPath(id_ == "tv_right", text_ == "允许")},
            "允许": {"type": Control, "path": UPath(id_ == "tv_right", text_ == "允许")},
            "下次再说": {"type": Control, "path": UPath(id_ == "tv_left", text_ == "下次再说")},
            "取消": {"type": Control, "path": UPath(id_ == "cancel", text_ == "取消",visible_==True)},
            "取消插件版": {"type": Control, "path": UPath(id_ == "sh", text_ == "取消",visible_==True)},
            "进入儿童/青少年模式": {"type": Control, "path": UPath(text_ == "进入儿童/青少年模式")},
            "好友推荐": {"type": Control, "path": UPath(id_ == "title_recommend_user", text_ == "好友推荐")},
            "好友推荐关闭": {"type": Control, "path": UPath(id_ == "close")},
            "上滑查看更多视频": {"type": Control, "path": UPath(text_ == "上滑查看更多视频")},
            #"上滑查看更多视频": {"type": Control, "path": UPath(id_ == "tv_strengthen_swipe_up_guide", text_ == "上滑查看更多视频")},
            "长按屏幕使用更多功能": {"type": Control, "path": UPath(id_ == "long_click_guide_title", text_ == "长按屏幕使用更多功能")},
            "不感兴趣": {"type": Control, "path": UPath(text_ == "不感兴趣")},
            "直播": {"type": Control, "path": UPath(id_ == "live_square_entrance_img")},
            "直播插件版": {"type": Control, "path": UPath(id_ == "h18")},
            "通知，是件很重要的事情":{"type": Control, "path": UPath(id_ == "tv_title", text_ == "通知，是件很重要的事情")},
            "稍后": {"type": Control, "path": UPath(id_ == "tv_left",text_ == "稍后")},
            "检测到更新": {"type": Control, "path": UPath(id_ == "title_text", text_ == "检测到更新")},
            "以后再说": {"type": Control, "path": UPath(id_ == "later_btn", text_ == "以后再说")},
            "设置抖音号": {"type": Control, "path": UPath(id_ == "title", text_ == "设置抖音号")},
            "完成": {"type": Control, "path": UPath(id_=="action",text_=="完成")},
            "关闭": {"type": Control, "path": UPath(id_=="close")},


        }


    def agree(self):
        print("进入到了我同意的页面")
        if self["我知道了"].wait_for_visible(timeout=10,raise_error=False):
            self["我知道了"].click()
            return
        if self["好的"].wait_for_visible(timeout=30,raise_error=False):
            self["好的"].click()
            return
        if self["同意"].wait_for_visible(timeout=4, raise_error=False):
            self["同意"].click()

    #获取主界面的activity
    def getActivity(self):
        return "com.ss.android.ugc.aweme.main.MainActivity"

    #检测登录是否成功
    def checked_login(self, device):
        print(device.get_current_activity())
        if device.get_current_activity() == "com.ss.android.ugc.aweme.account.business.login.DYLoginActivity":
            login_panel = LoginPanelhigh(root=self.app)
            num = login_panel.login()
            # mobile = self.resmgr.acquire("account", conditions={"tags":"1128"})
            # login_panel.login(self.device, mobile)
            time.sleep(10)

            if device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
                friend_panel = FriendPanel(root=self.app)
                friend_panel.skip()

            return num
        elif device.get_current_activity() == "com.ss.android.ugc.aweme.account.white.login.DYLoginActivity":
            login_panel = LoginPanel(root=self.app)
            num = login_panel.login()
            # mobile = self.resmgr.acquire("account", conditions={"tags":"1128"})
            # login_panel.login(self.device, mobile)
            time.sleep(10)

            if device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
                friend_panel = FriendPanel(root=self.app)
                friend_panel.skip()

            return num
        else:
            #没有进入登陆页面重试
            self.open_main_page("我")
            time.sleep(5)
            login_panel = LoginPanel(root=self.app)
            num = login_panel.login()
            time.sleep(10)
            if device.get_current_activity() == "com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity":
                friend_panel = FriendPanel(root=self.app)
                friend_panel.skip()
            return num

            return 0
    def wait_for_loading(self):
        self["页面"].wait_for_visible()

    def open_myself_page(self):
        time.sleep(3)
        self["我"].click()
    # 初始化
    def init(self, device):
        if self["通知，是件很重要的事情"].existing:
            if self["通知，是件很重要的事情"].visible:
                logger.info("通知，是件很重要的事情")
                self["稍后"].click()


        if self["个人信息保护指引"].existing:
            if self["个人信息保护指引"].visible:
                logger.info("个人信息")
                if self["好的"].wait_for_visible(timeout=5,raise_error=False):
                    self["好的"].click()
                if self["好的插件版"].wait_for_visible(timeout=5, raise_error=False):
                    self["好的插件版"].click()
                if self["同意"].wait_for_visible(timeout=4,raise_error=False):
                    self["同意"].click()


        if self["发现通讯录好友"].existing:
            if self["发现通讯录好友"].visible:
                logger.info("个人通讯录信息")
                if self["取消"].existing:
                    self["取消"].click()
                elif self["取消插件版"].existing:
                    self["取消插件版"].click()

        if self["进入儿童/青少年模式"].existing:
            if self["进入儿童/青少年模式"].visible:
                logger.info("青少年模式")
                self["我知道了"].click()

        if self["好友推荐"].existing:
            if self["好友推荐"].visible:
                logger.info("好友推荐")
                self["好友推荐关闭"].click()

        if self["上滑查看更多视频"].existing:
            if self["上滑查看更多视频"].visible:
                logger.info("上滑")
                device._driver.adb.shell_command("input swipe %s %s %s %s" % (
                    device.screen_rect.width // 2, device.screen_rect.height // 2,
                    device.screen_rect.width // 2, device.screen_rect.height // 20))

        time.sleep(2)

        if self["检测到更新"].existing:
            if self["以后再说"].visible:
                print("检测到更新")
                self["以后再说"].click()

        if self["长按屏幕使用更多功能"].existing:
            if self["长按屏幕使用更多功能"].visible:
                logger.info("长按")
                device._driver.adb.shell_command("input tap %s %s" % (device.screen_rect.width // 2, device.screen_rect.height // 3))

        if self["允许访问位置"].existing:
            if self["允许访问位置"].visible:
                logger.info("下次再说")
                self["下次再说"].click()

        if self["设置抖音号"].existing:
            self["完成"].click()
            time.sleep(4)

    """首页下方标签切换，点击两次"""

    def open_main_page(self, str):
        # self['同城'].click(offset_x=(-0.33) * self['同城'].rect.width)
        self[str].click()
        time.sleep(2)
        # 等待页面加载

    """进入直播广场(可以有多种方式）"""

    def open_live_page(self):
        try:
            if self["直播"].existing:
                self["直播"].click()
            if self["直播插件版"].existing:
                self["直播插件版"].click()
            try:
                self["直播"].wait_for_invisible()
            except:
                if self["直播"].existing:
                    self["直播"].click()
                if self["直播插件版"].existing:
                    self["直播插件版"].click()
                self["直播"].wait_for_invisible()

        except:
            self["LIVE"].click()
            try:
                self["LIVE"].wait_for_invisible()
            except:
                self["LIVE"].click()
                self["LIVE"].wait_for_invisible()
        time.sleep(2)
        # 等待页面加载


    """刷新feed"""

    def refresh(self):
        self["页面"].pull_down_refresh()
        time.sleep(5)

    """拍摄直播"""

    def start_new_live(self):
        if self["拍摄按钮"].existing:
            self["拍摄按钮"].click()
        elif self["拍摄按钮插件版"].existing:
            self["拍摄按钮插件版"].click()
    def setting(self):
        self["设置"].click()
        self["DebugTest"].click()

    """退出登录"""
    def logout(self, device):
        self.open_main_page("我")
        self.init(device)
        #self["设置"].wait_for_invisible()
        self["设置"].click()
        self["设置页的设置"].click()
        setting_panel = SettingPanel(root=self.app)
        setting_panel.logout(device)




# -*- coding: UTF-8 -*-
import time
from shoots_android.control import *
from uibase.upath import *


class Assistant(Window):
    '''Home界面-底部我的
    '''
    window_spec = {"activity": "com.bytedance.ies.assistant.AssistantActivity",  # 所在的Activity,不能为空
                   "process_name": None}

    def get_locators(self):
        return {"用户": {'type': Control, 'path': UPath(id_ == "header_image")},
                "设置": {"type": Control, "path": UPath(id_ == "more_btn")},
                "DebugTest": {"type": Control, "path": UPath(text_ == "Debug Test")},
                'area': {'type': Control, 'path': UPath(id_ == 'item_sec_uid_checker')},
                "滚出": {'type': Control, 'root': 'area', 'area': UPath(id_ == "right_layout" )},
                }

    def wait_for_loading(self):
        time.sleep(1)
        self["用户"].wait_for_visible()

    def remove_uid(self, device):
        '''
        根据用户图标是否可视判断是否登录状态
        :return:
        '''
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, 2 * device.screen_rect.height // 3,
            device.screen_rect.width // 2, device.screen_rect.height // 3))
        self["滚出"].click()

        device._driver.adb.shell_command("input keyevent 4")
        device._driver.adb.shell_command("input keyevent 4")


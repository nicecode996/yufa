# -*- coding: utf8 -*-

import os
import logging


from shoots_android.androidapp import AndroidApp
from shoots_android_byted import AndroidAppMixin
from shoots import logger
import os
from douyinlib.main_panel import MainWindow
from shoots.config import settings
from shoots import logger
import os
#为抓包临时添加
# import ssl
# try:
#     _create_unverified_https_context = ssl._create_unverified_context
# except AttributeError:
#     # Legacy Python that doesn't verify HTTPS certificates by default
#     pass
# else:
#     # Handle target environment that doesn't support HTTPS verification
#     ssl._create_default_https_context = _create_unverified_https_context

class DouYinApp(AndroidApp,AndroidAppMixin):
    app_spec = {
        "package_name": "com.ss.android.ugc.aweme",  # app package name
        "init_device": True,  # whether to wake up device
        "process_name": "",  # main process name of app
        "start_activity": ".main.MainActivity",  # start activity
        "grant_all_permissions": True,  # grant all permissions before starting app
        "clear_data": True,  # pm clear app data
        "kill_process": True  # whether to kill previously started app
    }
    popup_rules = []


    def login(self):
        pass

    def pushMockFile(self):
        cur_dir = os.path.split(os.path.realpath(__file__))[0]
        mock_file = os.path.join(cur_dir, "mockFile.json")
        if os.path.exists(mock_file):
            dest_path = "/sdcard/Android/data/{}/files/mockFile.json".format(self.package_name)
            self.get_device().push_file(mock_file, dest_path)
        else:
            logging.info("mockFile 文件不存在")


    def __init__(self, *args, **kwargs):
        # ci任务触发可能是内测包、正常包，根据任务情况修改被测包名
        if hasattr(settings, 'RUNNER_TASK_INFO') and settings.RUNNER_TASK_INFO.get("pkgName", None):
            test_package_name = settings.RUNNER_TASK_INFO.get("pkgName", None)
            if test_package_name in ['com.ss.android.ugc.aweme']:
                self.app_spec["package_name"] = test_package_name
                logger.info("当前测试任务被测包名为{}".format(test_package_name))
            else:
                raise RuntimeError("测试任务的包名非当前工程支持包名")

        super(DouYinApp, self).__init__(*args, **kwargs)
        self.close_other_page()
        self.pre_install_plugins()  # 启动后将安装插件

    def close_other_page(self, times=5):
        """
        如果5秒内跳到了主activity则证明启动成功，非主要activity则根据当前activity做处理。

        第一次启动app隐私弹窗可能在主activity或闪屏activity出现

        未做处理则抛出异常信息
        :return:
        """
        try:
            self.wait_for_activity(
                MainWindow.window_spec['activity'], timeout=3, interval=0.3)

            self._agree_privacy = MainWindow(root=self).agree()
        except RuntimeError as e:
            if not hasattr(e, "current_activity"):
                raise e
            logger.warning(str(e))
            cur_activity = e.current_activity
            if cur_activity is None or cur_activity == MainWindow.window_spec['activity']:
                logger.warning("当前activity:{},不做处理".format(cur_activity))
            else:
                logger.warning(
                    "当前activity:{}非首页activity，当前方法未对此弹窗做处理，抛出异常".format(cur_activity))
                raise e

            if times == 0:
                raise RuntimeError(
                    "当前activity:{}非首页activity".format(cur_activity))
            self.close_other_page(times - 1)

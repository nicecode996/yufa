# -*- coding: utf8 -*-
from shoots_android.control import *
from uibase.upath import *


class LiveSquare(Window):
    """
    直播广场
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.live.LiveFeedActivity"}

    def get_locators(self):
        return {
            "直播广场-进入": {"type": Control, "path": UPath(id_ == "live_cover", visible_ == True, index= 0)},
            "直播广场-返回": {"type": Control, "path": UPath(id_ == "back_btn",desc_ == "返回")},

            "非法错误": {"type": Control, "path": UPath(text_ == "非法错误")},
            "好的": {"type": Control, "path": UPath(text_ == "好的，知道了，一会儿去联系")}

        }
    """进入直播的几种方式"""
    """
    (1) 首页-LIVE-直播广场-点击主播
    (2) 同城-点击主播
    (3) 点击正在直播的主播头像
    (4) 搜索
    """
    """ 直播广场的操作"""
    def go_living(self):
        #进入直播间

        try:
            self["直播广场-进入"].click()
        except:
            try:
                self["非法错误"].visible()
                self["好的"].click()
                self["直播广场-进入"].click()
            except:
                raise RuntimeError("进入直播广场失败")
        time.sleep(2)

    def go_out_square(self):
        try:
            self["直播广场-返回"].click()
        except:
            try:
                self["非法错误"].visible()
                self["好的"].click()
                self["直播广场-返回"].click()
            except:
                raise RuntimeError("退出直播广场失败")
        time.sleep(2)



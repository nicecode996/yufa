# -*- coding: utf8 -*-
from shoots_android.control import *
from uibase.upath import *
from douyinlib.common.AnchorLivingRoom_panel import *

class StartVideo(Window):
    """
    开始短视频和直播集合
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.shortvideo.ui.VideoRecordNewActivity"}

    def get_locators(self):
        return {
            "开直播": {"type": Control, "path": UPath(text_ == "开直播",visible_ == True)},
            "开始视频直播": {"type":Control, "path": UPath(text_ == "开始视频直播")},
            "正在加载资源": {"type": Control, "path": UPath(text_ == "正在加载资源…")},
            "返回": {"type": Control, "path": UPath(id_ == "img_close_record",desc_ == "关闭")},
            "非法错误": {"type": Control, "path": UPath(text_ == "非法错误")},
            "好的": {"type": Control, "path": UPath(text_ == "好的，知道了，一会儿去联系")},
            "直播意外中断了, 是否继续直播?": {"type": Control, "path": UPath(text_ == "直播意外中断了, 是否继续直播?")},
            "取消": {"type": Control, "path": UPath(text_ == "取消")},
            "正在加载资源…": {"type": Control, "path": UPath(desc_ == "正在加载资源…")},
            #"正在加载资源…": {"type": Control, "path": UPath(id_ == "message", desc_ == "正在加载资源…")},
        }
    def start_living(self):
        #开直播

        try:
            self["开直播"].click()
            self["正在加载资源…"].wait_for_visible(timeout=15,raise_error=False)
            self["正在加载资源…"].wait_for_invisible(timeout=100, raise_error=False)
            #time.sleep(10)
        except:
            try:
                self["非法错误"].visible()
                self["好的"].click()
                self["开直播"].click()
                self["正在加载资源…"].wait_for_visible(timeout=15,raise_error=False)
                self["正在加载资源…"].wait_for_invisible(timeout=100, raise_error=False)
                #time.sleep(10)
            except:
                pass


        time.sleep(2)


        if self["直播意外中断了, 是否继续直播?"].existing:
            self["取消"].click()


        for _ in Retry(timeout=700, interval=1, raise_error=False):
            if self["开始视频直播"].visible:
                self["开始视频直播"].click()
                return True
        else:
            raise Exception("开始视频直播处发生错误")







    def out_video(self):
        self["返回"].click()
        time.sleep(2)



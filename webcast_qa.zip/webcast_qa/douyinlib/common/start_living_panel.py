# -*- coding: utf8 -*-
from shoots_android.control import *
from uibase.upath import *


class StartLiving(Window):
    """
    开始直播
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.live.LiveBroadcastActivity"}

    def get_locators(self):
        return {
            "开直播": {"type": Control, "path": UPath(text_ == "开直播")},
            "返回": {"type": Control, "path": UPath(id_ == "close")},
            "退出提示": {"type": Control, "path": UPath(text_ == "提示", id_ == "live_dialog_title")},
            "确定退出": {"type": Control, "path": UPath (text_ == "确定", id_ == "live_dialog_btn_1")},
            "退出反馈": {"type": Control, "path": UPath (id_ == "live_end_play_background")},
            "回到主页": {"type": Control, "path": UPath (id_ == "back_to_main")}
        }

    def out_living_room(self):
        #退出直播
        self["返回"].click()
        self["退出提示"].wait_for_visible()
        self["确定退出"].click()
        self["退出反馈"].wait_for_visible()
        self["回到主页"].click()




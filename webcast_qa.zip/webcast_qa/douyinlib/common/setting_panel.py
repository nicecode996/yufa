# -*- coding: utf8 -*-
"""设置
"""

from shoots_android.control import *
from uibase.upath import *

class SettingPanel(Window):
    """setting window
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.setting.ui.DouYinSettingNewVersionActivity"}

    def get_locators(self):
        return{
            "退出登录": {"type": Control, "path": UPath(text_ == "退出登录")},
            "退出":{"type": Control, "path": UPath(id_ == "button1", text_ == "退出")},
        }

    def logout(self, device):
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, 4 * device.screen_rect.height // 5,
            device.screen_rect.width // 2, device.screen_rect.height // 5))
        time.sleep(2)
        self["退出登录"].click()
        self["退出"].click()
        self.app.wait_for_activity("com.ss.android.ugc.aweme.splash.SplashActivity")
        #self.assert_("未成功退出登录", (self.device.current_activity == "com.ss.android.ugc.aweme.splash.SplashActivity"))

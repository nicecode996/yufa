# -*- coding: UTF-8 -*-
import sys

import time
from shoots_android.control import *
from uibase.upath import *
from shoots import logger
from webcastlib.mobile_account import MobileRequest
import requests
import json
import random
headers = {'Content-Type': 'application/json'}

class LoginPanel(Window):
    '''登录界面   底部-我的-登录按钮
    '''
    window_spec = {"activity": 'com.ss.android.ugc.aweme.account.white.login.DYLoginActivity',
               # 所在的Activity,不能为空
               "process_name": None}

    def get_locators(self):
        return {
            "返回": {"type": Control, "path": UPath(id_ == "back")},
            "一键登录": {"type": Control, "path": UPath(id_ == "normal_state", text_ == "一键登录")},
            "其他手机号码登录": {"type": Control, "path": UPath(id_ == "normal_state", text_ == "其他手机号码登录")},
            "密码登录": {"type": Control, "path": UPath(text_ == "密码登录")},
            "获取短信验证码": {"type": Control, "path": UPath(text_ == "获取短信验证码", visible_ == True)},

            "手机号": {"type": TextView, "path": UPath(id_ == "phone_input_view", visible_ == True)},
            "手机号插件包": {"type": TextView, "path": UPath(id_ == "ccy", visible_ == True)},
            "输入验证码": {"type": TextView, "path": UPath(id_ == "sms_code")},
            "输入验证码插件版": {"type": TextView, "path": UPath(id_ == "db5")},

            "同意": {"type": Control, "path": UPath(id_ == "privacy_check")},
            "同意插件版": {"type": Control, "path": UPath(id_ == "cls")},
            "本机手机号": {"type":Control, "path": UPath(id_ == "one_key_login_phone_number")},


            "登录": {'type': Control, 'path': UPath(text_ == "登录", visible_ == True)},
            "跳过": {"type": Control, "path": UPath(text_ == "跳过", visible_ == True)}
        }

    def login(self):
        g = MobileRequest()
        num = g.get_num(tags = 1128)
        # account = self.resmgr.acquire("account")
        self.usrname = num
        self.usrcode = "0819"
        logger.info(num)

        if self["一键登录"].existing:
            self["一键登录"].click()
            time.sleep(1)
        if self["本机手机号"].existing:
            self["其他手机号码登录"].click()
            time.sleep(1)
        if self["手机号"].existing:
            self["手机号"].text = self.usrname
            self["手机号"].text = self.usrname
        elif self["手机号插件包"].existing:
            self["手机号插件包"].text = self.usrname
            self["手机号插件包"].text = self.usrname
        while self["获取短信验证码"].existing:
            self["获取短信验证码"].click()
            time.sleep(5)
        if self["输入验证码"].existing:
            self["输入验证码"].text = self.usrcode
        elif self["输入验证码插件版"].existing:
            self["输入验证码插件版"].text = self.usrcode

        time.sleep(2)
        if self["同意"].existing:
            self["同意"].click()
        elif self["同意插件版"].existing:
            self["同意插件版"].click()
            
        if self["登录"].existing:
            self["登录"].click()
        if self["登录"].existing:
            self["登录"].click()

        time.sleep(2)
        return num





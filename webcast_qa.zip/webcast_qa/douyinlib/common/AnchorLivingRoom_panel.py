# -*- coding: utf8 -*-

'''
    主播开播页面
'''

from shoots_android.control import *
from uibase.upath import *

class AnchorLivingRoom(Window):

    window_spec = {"activity": "com.ss.android.ugc.aweme.live.LiveBroadcastActivity"}

    def get_locators(self):
        return{
            "重要通知": {"type": Control, "path": UPath(text_ == "重要通知")},
            "继续直播": {"type": Control, "path": UPath(text_ == "继续直播")},
            #"关播A": {"type": Control, "path": UPath(id_ == "close")},
            "关播B": {"type": Control, "path": UPath(id_ == "action_container")/UPath(id_=="icon",depth=2,index=2)},
            "关播插件版": {"type": Control, "path": UPath(id_ == "iwa")},
            "关播插件版2": {"type": Control, "path": UPath(id_ == "iw4")},#版本变动之后的关播方式
            "提示": {"type": Control, "path": UPath(text_ == "提示")},
            "确定":{"type": Control, "path": UPath(text_ == "确定")},
            "主播信息": {"type":Control, "path": UPath(id_ == "anchor_info_container",visible_==False)},
            "主播信息插件版": {"type":Control, "path": UPath(id_ == "av9",visible_==True)},
            "主播信息低版本": {"type":Control, "path": UPath(id_ == "head",visible_==True)},
            "结束页关闭按钮": {"type": Control, "path": UPath(id_ == "back_to_main")},
            "动作按钮":{"type":Control, "path": UPath(id_ == "action_container")},
            "关播新样式": {"type": Control, "root": "动作按钮", "path": UPath(index= -2)},
            "关闭直播": {"type": Control, "path": UPath(id_== "default_toolbar_icon",index=-1)},
            "确定关闭直播": {"type": Control, "path": UPath(id_== "live_dialog_btn_1",text_=="确定")},
            "确定关闭直播插件版": {"type": Control, "path": UPath(id_== "bpm",text_=="确定")},
            "返回主页": {"type": Control, "path": UPath(id_== "back_to_main")},
            "返回主页插件版": {"type": Control, "path": UPath(id_== "kr")},

            "更多":{"type":Control, "root": "动作按钮", "path": UPath(index=-2)},
            #"更多上的黄点":{"type":Control, "root": "动作按钮", "path": UPath(id_ == "view_red_dot")},
            "更多面板":{"type":Control, "path": UPath(id_ == "ttlive_design_bottom_sheet")},
            "页面中间":{"type":Control, "path": UPath(id_ == "ttlive_anchor_task_finish_animation_view")},
            "礼物":{"type":Control, "root": "更多面板", "path": UPath(text_ == "礼物")},
            "粉丝团": {"type": Control, "root": "更多面板", "path": UPath(text_ == "粉丝团")},
            "礼物列表":{"type":Control, "path": UPath(id_ == 'list')},
            "礼物a": {"type": Control, "root": "礼物列表", "path": UPath(index=0)},#小心心礼物
            "礼物b": {"type": Control, "root": "礼物列表", "path": UPath(index=1)},#樱花(礼物）
            "发送按钮":{"type": Control, "path": UPath(id_ == "send")},
            "直播间消息":{"type": Control, "path": UPath(id_ == "messages_view")},
            "小礼物托盘": {"type": Control, "path": UPath(id_ == "base_gift_view")},
            "大礼物托盘": {"type": Control, "path": UPath(id_ == "user_view")},
            "左右滑动切换滤镜":{"type": Control, "path": UPath(text_ == "左右滑动切换滤镜")},
            "礼物面板关闭按钮": {"type": Control, "path": UPath(id_ == "close_btn_view")},
        }

    def Scroll(self):
        if self["左右滑动切换滤镜"].existing:
            if self["左右滑动切换滤镜"].visible:
                print("左右滑动切换滤镜")
                self["左右滑动切换滤镜"].click()

    def continueliving(self):
        try:
            if self["重要通知"].visible:
                print("hahha")
                self["继续直播"].click()
                self["重要通知"].wait_for_invisible()
        except:
            pass

    def BroadcastSuccesful(self):
        time.sleep(3)
        if self["主播信息"].existing or self["主播信息低版本"].existing or self["主播信息插件版"].existing:
            return 0
        else:
            return 1

    def endBroadcastSuccesful(self):
        if self["结束页关闭按钮"].visible:
            return 0
        else:
            return 1

    def closeliving(self):

        """

        :return:
        """
        # if self["关播新样式"].visible:
        #    self["关播新样式"].click()
        #    self["提示"].wait_for_visible()
        #    self["确定"].click()
        #    #time.sleep(15)
        #    self["结束页关闭按钮"].wait_for_visible()
        #    self["结束页关闭按钮"].click()

        try:
            if self["关播B"].wait_for_visible(timeout=4,raise_error=False):
                self["关播B"].click()
            elif self["关播插件版2"].wait_for_visible(timeout=4,raise_error=False):
                self["关播插件版2"].click()
            elif self["关播插件版"].wait_for_visible(timeout=4,raise_error=False):
                self["关播插件版"].click()



        except:
            if self["关闭直播"].wait_for_visible(timeout=5, raise_error=False):
                self["关闭直播"].click()
                time.sleep(5)

        if self["确定关闭直播"].wait_for_visible(timeout=5,raise_error=False):
            self["确定关闭直播"].click()
        elif self["确定关闭直播插件版"].wait_for_visible(timeout=5, raise_error=False):
            self["确定关闭直播插件版"].click()

        time.sleep(3)

        if self["返回主页"].wait_for_visible(timeout=5, raise_error=False):
            self["返回主页"].click()
        elif self["返回主页插件版"].wait_for_visible(timeout=5, raise_error=False):
            self["返回主页插件版"].click()

    def sendGifta(self):
        try:
            self["更多"].click()
            time.sleep(2)
            if self["更多面板"].wait_for_visible(timeout=10, raise_error=False):
                print("打开更多面板")
            else:
                if self["页面中间"].wait_for_visible(timeout=10, raise_error=False):
                    self["页面中间"].click()
                time.sleep(5)
                self["更多"].click()
                time.sleep(5)
        except:
            if self["页面中间"].wait_for_visible(timeout=10, raise_error=False):
                self["页面中间"].click()
            self["更多"].click()
            time.sleep(2)
            self["更多面板"].wait_for_visible(timeout=10, raise_error=False)

        if self["礼物"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物"].click()
            time.sleep(5)
        #送小心心礼物
        if self["礼物a"].wait_for_visible(timeout=10, raise_error=False):
            self["礼物a"].click()
            self["礼物a"].click()
            # #新版本没有托盘
            # for _ in Retry(timeout=10, interval=0.1, raise_error=False):
            #     if self["小礼物托盘"].existing:
            #         if self["小礼物托盘"].visible:
            #             return 0
            #     if self["大礼物托盘"].existing:
            #         if self["大礼物托盘"].visible:
            #             return 0


    """
    def sendGiftb(self):
        if self["礼物b"].wait_for_visible():
            self["礼物b"].click()
            self["礼物b"].click()
    """

    def sendGiftSuccesful(self):
        # for _ in Retry(timeout=10, interval=0.2, raise_error=False):
        #     if self["小礼物托盘"].existing or self["大礼物托盘"].existing:
        #         time.sleep(10)
        #         return 0
        # else:
        #     return 1
        child_ids = self["直播间消息"].children
        num =len(child_ids)
        if num > 1:
            return 0
        else:
            return 1

    def closeGiftpanel(self):
        if self["礼物列表"].existing:
            self["礼物面板关闭按钮"].click()
            self["礼物面板关闭按钮"].wait_for_invisible()






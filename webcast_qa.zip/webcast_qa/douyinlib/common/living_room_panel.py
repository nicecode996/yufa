# -*- coding: utf8 -*-
"""
直播间
"""


from shoots_android.control import *
from uibase.upath import *

class VideoType():
    VIDEO = 0
    STAGE_LIVE = 1
    GAME_LIVE = 2

class WatchLiving(Window):
    """
    live room
    """
    window_spec = {"activity": "com.ss.android.ugc.aweme.live.LivePlayActivity"}

    def get_locators(self):
        return {
            "页面": {"type": ScrollView, "path": UPath(id_ == "content", index=0)},
            "返回": {'type': Control, 'path': UPath(id_ == "close",visible_ == True)},
            '礼物面板-入口':{'type': Control, 'path': UPath(id_ == 'live_gift', index=0) },
            # 游戏直播专有
            '打开专区':{'type': Control, 'path': UPath(id_ == 'live_audience_gzone_entry_normal_text_view') },

            #弹窗
            '关注并退出':{'type': Control, 'path': UPath(id_ == 'follow_btn')},
            '关闭弹窗': {'type': Control, 'path': UPath(id_ == 'close_btn')},
            '关闭a': {'type': Control, 'path': UPath(id_ == 'close_btn', visible_ == True)},
            '关闭b': {'type': Control, 'path': UPath(id_ == 'close', visible_ == True)},

            "非法错误": {"type": Control, "path": UPath(text_ == "非法错误")},
            "好的": {"type": Control, "path": UPath(text_ == "好的，知道了，一会儿去联系")},
            "关注": {"type": Control, "path": UPath(id_ == "follow", text_ == "关注")},
            "粉丝团入口": {"type": Control, "path": UPath(id_ == "fans")},
            "左滑查看更多直播": {"type": Control, "path": UPath(text_ == "左滑查看更多直播")},
            "上下滑动切换内容": {"type": Control, "path": UPath(text_ == "上下滑动切换内容")},
            "上滑查看更多内容": {"type": Control, "path": UPath(text_ == "上滑查看更多内容")},
            "为你推荐更多主播": {"type": Control, "path": UPath(id_ == "room_quit_title", text_ == "为你推荐更多主播")},
            "退出": {"type": Control, "path": UPath(id_ == "room_quit_button_left", text_ == "退出")},
            "主播昵称":{"type": Control, "path": UPath(id_ == 'user_name')},
            "媒体直播间主播昵称":{"type": Control, "path": UPath(id_ == 'media_anchor_name')},
            "您正在直播中，是否继续直播?":{"type":Control, "path":UPath(text_ =="您正在直播中，是否继续直播？")},
            "结束直播":{"type":Control, "path":UPath(text_ == "结束直播")},
            "右下banner": {"type": Control, "path": UPath(id_ == 'bottom_right_banner_container')},
            "电商小窗": {"type": Control, "path": UPath(id_ == 'ec_promotion_card_container')},
            "关闭电商小窗": {"type": Control, "path": UPath(id_ == 'iv_close_card')}
        }
    """进入直播的几种方式"""
    """
    (1) 首页-LIVE-直播广场-点击主播
    (2) 同城-点击主播
    (3) 点击正在直播的主播头像
    (4) 搜索
    """
    """ 直播广场的操作"""
    def out_living_room(self):
        try:
            self["返回"].click()
        except:
            try:
                self["非法错误"].visible()
                self["好的"].click()
                self["返回"].click()
            except:
                raise RuntimeError("退出直播间")

    """切换直播页面"""
    def refresh(self):
        self["页面"].scroll_down_one_page()
        time.sleep(2)

    """获取视频类型"""
    def getVideoType(self):
        if not self['礼物面板-入口'].existing :
            return VideoType.VIDEO
        if self['打开专区'].existing :
            return VideoType.GAME_LIVE
        return VideoType.STAGE_LIVE


    """返回feed"""
    def goBackToFeed(self):
        self._device_driver.send_key(4)
        time.sleep(1)
        if self['退出'].existing :
            self['退出'].click()


    def scroll_to_nextroom(self, device):
        device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            device.screen_rect.width // 2, 3 * device.screen_rect.height // 7,
            device.screen_rect.width // 2, device.screen_rect.height // 30))
        time.sleep(5)

    def scroll_until_not_media_living_room(self, device):
        while self["媒体直播间主播昵称"].existing:
            self.scroll_to_nextroom(device)
        else:
            pass

    def isliving(self):
        time.sleep(10)
        if self["结束直播"].existing:
            self["结束直播"].click()
        time.sleep(5)

    def follow_anchor(self, device):
        if self["关注"].visible:
            self["关注"].click()
            time.sleep(4)
            if self["粉丝团入口"].visible:
                return 0
        else:
            while self["粉丝团入口"].visible:
                self.scroll_to_nextroom(device)
            if self["关注"].visible:
                self["关注"].click()
                time.sleep(2)
                if self["粉丝团入口"].visible:
                    return 0
            else:
                return 1

    def swipe(self, x_direction=0, y_direction=1, swipe_coefficient=3):
        '''滑动

        :param x_direction: 大于0向左，小于0向右
        :param y_direction: 大于0向上，小于0向下
        后续会支持斜着滑动

        :param coefficient:滑动系数 ,决定滑动距离，系数允许范围（2，8]
        '''

        if swipe_coefficient <= 2 or swipe_coefficient > 8:
            raise ValueError("coefficient range is （2，8]")

        rect = self.ensure_visible()
        if y_direction > 0 and x_direction == 0:
            x1 = x2 = rect.left + rect.width // 2
            y1 = rect.top + rect.height * (swipe_coefficient - 1) // swipe_coefficient
            y2 = rect.top + rect.height // swipe_coefficient
        elif y_direction < 0 and x_direction == 0:
            x1 = x2 = rect.left + rect.width // 2
            y1 = rect.top + rect.height // swipe_coefficient
            y2 = rect.top + rect.height * (swipe_coefficient - 1) // swipe_coefficient
        elif x_direction > 0 and y_direction == 0:
            y1 = y2 = rect.top + rect.height // 2
            x1 = rect.left + rect.width * (swipe_coefficient - 1) // swipe_coefficient
            x2 = rect.left + rect.width // swipe_coefficient
        elif x_direction < 0 and y_direction == 0:
            y1 = y2 = rect.top + rect.height // 2
            x1 = rect.left + rect.width // swipe_coefficient
            x2 = rect.left + rect.width * (swipe_coefficient - 1) // swipe_coefficient
        else:
            raise ValueError("not support this direction x {}  y{}".format(x_direction, y_direction))

        self._driver.drag(self.id, x1, y1, x2, y2)
        time.sleep(1)

    def drag(self, to_x, to_y, offset_x=0, offset_y=0, duration=None, count=None):
        rect = self.ensure_visible()
        center = rect.center
        x = float(center[0] + offset_x)
        y = float(center[1] + offset_y)
        return self._driver.drag(self.id,
                                 from_x=x,
                                 from_y=y,
                                 to_x=float(to_x),
                                 to_y=float(to_y),
                                 duration=duration,
                                 count=count)

    def swipe_for_change_room(self,y_direction=1,swipe_coefficient=3):
        old_anchor_name = self.get_anchor_name()
        self.swipe(y_direction=y_direction,
                   swipe_coefficient=swipe_coefficient)
        time.sleep(5)
        if self.get_anchor_name() != old_anchor_name:
            return 0
        else:
            return 1
    def quit_room_pop_handle(self):
         if self["左滑查看更多直播"].existing:
            if self["左滑查看更多直播"].visible:
                self["左滑查看更多直播"].click()
                if self["关闭a"].existing:
                    self["关闭a"].click()
                else:
                    self["关闭b"].click()
         if self["上下滑动切换内容"].existing:
            if self["上下滑动切换内容"].visible:
                self["上下滑动切换内容"].click()
                if self["关闭a"].existing:
                    self["关闭a"].click()
                else:
                    self["关闭b"].click()

         if self["上滑查看更多内容"].existing:
            if self["上滑查看更多内容"].visible:
                self["上滑查看更多内容"].click()
                if self["关闭a"].existing:
                    self["关闭a"].click()
                else:
                    self["关闭b"].click()

         if self["为你推荐更多主播"].existing:
            if self["为你推荐更多主播"].visible:
                self["退出"].click()

    def quit_room(self):
        if self["关闭a"].existing:
            self["关闭a"].click()
        else:
            self["关闭b"].click()

        time.sleep(5)
        self.quit_room_pop_handle()
        time.sleep(5)
        self.quit_room_pop_handle()


    def get_anchor_name(self):
        return self['主播昵称'].text

    def isWctchingLive(self, device):
        try:
            if device.current_activity == "com.ss.android.ugc.aweme.live.LivePlayActivity" or self['主播昵称'].visible:
                return 0
            else:
                return 1
        except:
            return 1

    def Centerclick(self, device):
        device._driver.adb.shell_command(
            "input tap %s %s" % (device.screen_rect.width // 2, device.screen_rect.height // 3))

    def jump_webview(self):
        schema_url="sslocal://webcast_webview?url=http%3A%2F%2Ftest-aweme.snssdk.com%2Ffalcon%2Fjsb_tester_web%2Fdmt%2F%3F__live_platform__%3Dwebcast%26caseId%3D%26groupId%3D18%26author%3Dliqianying%26authorId%3D1927070%26isAutoTest%3D%26productionId%3D6"

        self.get_driver()[""].call_static_method("com.bytedance.android.livesdk.test.AutoTestUtils", "handleSchema", None,
                                                 "void", schema_url)

# -*- coding: UTF-8 -*-
import sys

import time
from shoots_android.control import *
from uibase.upath import *

class FriendPanel(Window):
    '''登陆后是否添加通讯录好友
    '''
    window_spec = {"activity": 'com.ss.android.ugc.aweme.friends.ui.RecommendContactActivity',
               # 所在的Activity,不能为空
               "process_name": None}

    def get_locators(self):
        return {
            "跳过": {"type": Control, "path": UPath(id_ == "skip_white",text_ == "跳过")},
            "跳过插件版": {"type": Control, "path": UPath(id_ == "dag",text_ == "跳过")},
        }

    def skip(self):
        if self["跳过"].existing:
            self["跳过"].click()
        elif self["跳过插件版"].existing:
            self["跳过插件版"].click()
        print("退出")

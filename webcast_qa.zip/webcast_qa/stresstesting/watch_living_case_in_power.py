# -*- coding: UTF-8 -*-
from douyinlib.testcase import DouyinTest
from douyinlib.app import DouYinApp
from douyinlib.main_panel import MainWindow
from douyinlib.common.login_panel import LoginPanel
from douyinlib.common.living_square_panel import LiveSquare
from douyinlib.common.living_room_panel import WatchLiving
from douyinlib.common.start_video_panel import StartVideo
from douyinlib.common.start_living_panel import StartLiving
import time
import logging
"""
case: 进入抖音直播间观看直播
"""

class GoInLiveRoomUnderPower(DouyinTest):
    """
    进入抖音直播间
    """
    owner = "wuting.scnc"
    timeout = 1000
    app = 'douyin'
    ip = ''


    def run_test(self):
        self.device = self.acquire_device()
        self.app = DouYinApp(self.device)
        self.home = MainWindow(root=self.app)
        self.app.pushMockFile()

        """case1 进入操作"""
        self.start_step("case1 打开app-初始化，进入首页")
        self.home.init()

        time.sleep(5)
        self.pop_processing()  # 因为主端频控问题，暂时注释

        """case2 登录操作"""
        try:
            self.home.open_main_page("首页")  # 弹窗可能
            time.sleep(2)
            self.home.open_main_page("首页")  # 弹窗可能
            time.sleep(2)
            self.start_step("确保已经登录")
            self.home.open_main_page("我")
        except:
            #   重启一次
            # device = self.acquire_device()
            # device._driver.adb.shell_command("input tap 500 1000")
            # app = DouYinApp(device)
            # self.home = MainWindow(root=app)
            """case1 进入操作"""
            self.start_step("打开app-初始化，进入首页")
            self.home.init()

            self.start_step("确保已经登录")
            self.home.open_main_page("我")

        time.sleep(2)

        self.home.init()

        if self.device.get_current_activity() == "com.ss.android.ugc.aweme.account.white.login.DYLoginActivity":
            login_panel = LoginPanel(root=self.app)
            login_panel.login(self.device, self.resmgr.acquire("account"))
        else:
            self.home.open_main_page("我")
            login_panel = LoginPanel(root=self.app)
            login_panel.login(self.device, self.resmgr.acquire("account"))

        time.sleep(2)
        self.home.open_main_page("首页")
        time.sleep(2)

        self.home.init()

        """case 3从直播广场进入直播间操作并返回到首页"""

        self.start_step("打开LIVE")
        self.home.init()
        self.home.working_with_contacts() #处理通讯录弹窗
        time.sleep(2)
        self.home.open_live_page()
        time.sleep(5)

        if self.device.get_current_activity() == "com.ss.android.ugc.aweme.live.LivePlayActivity":
            self.start_step("进入直播间")
            self.process_watch_living()

        elif self.device.get_current_activity() == "com.ss.android.ugc.aweme.live.LiveFeedActivity": #老逻辑，点击live进入直播广场
            #直播广场
            self.start_step("进入直播广场")
            live_square = LiveSquare(root = self.app)
            live_square.wait_for_activity(live_square.activity)
            self.start_step("进入直播间")
            live_square.go_living()
            self.process_watch_living()
        else:
            raise RuntimeError("无法进入直播间")

        self.start_step("上下滑切换直播间")
        WatchLiving_panel = WatchLiving(root=self.app)
        self.assert_("未成功上下滑直播间",
                     WatchLiving_panel.scroll_to_nextroom(self.device) == 0)


    def process_watch_living(self):
        """直播间操作"""
        live_room = WatchLiving(root = self.app)
        live_room.wait_for_activity(live_room.activity)
        time.sleep(5)
        self.assert_("未成功观看直播",
        self.device.current_activity == "com.ss.android.ugc.aweme.live.LivePlayActivity")

        logging.info("-----------成功进入观看直播--------------")


    def pop_processing(self):#弹窗处理，尽量通过点击进行弹窗处理,不能点击到无效区域
        width = self.device.screen_rect.width
        height = self.device.screen_rect.height
        #self.device._driver.adb.shell_command("input tap %s %s"%(width//2,height//3)) 这个方法不太行了，短视频feed也会有直播，点击容易进入直播间
        #self.device._driver.adb.shell_command("input tap %s %s" % (width // 2, height // 3))
        self.device._driver.adb.shell_command("input swipe %s %s %s %s" % (
            self.device.screen_rect.width // 2, 2*self.device.screen_rect.height // 3,
            self.device.screen_rect.width // 2, self.device.screen_rect.height // 4))

if __name__ == '__main__':
    go = GoInLiveRoomUnderPower()
    go.debug_run()





# -*- coding: utf8 -*-
"""project settings extension file:
    this file is in .gitignore;
    don't commit this file.
"""
# "8GP4C18502002610"  华为nova
# "85d6f3b6" vivo y66
# "110a879" oppo A57 白色
# "4aec252" OPPO A57 黑色
DEVICE_UDID = "3ee4c4df"


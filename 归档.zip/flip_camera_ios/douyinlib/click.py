# -*- coding: utf-8 -*-
# @Time : 2020/8/3 11:51 上午
# @Author : Zhangfusheng
# @File : ios_click.py


class iOS_Click:
    def __init__(self, name):
        """需要维护在测试机上各个app切换前后摄像头的坐标位置"""
        self.ios_coordinates = {"抖音": [625, 2133], "西瓜": [1037, 126], "火山": [1037, 2129], "皮皮虾": [1141, 145],
                                "快手": [1148, 93],
                                "斗鱼": [372, 112],
                                "花椒": [1153, 113], "YY": [1173, 113], "映客": [597, 127]}
        # self.coordinates = self.ios_coordinates[name]
        """直播中切换摄像头坐标位置"""
        self.ios_coordinates = {"抖音2": [1037, 126], "西瓜": [881, 2114], "火山": [889, 2117], "皮皮虾": [1172, 2135],
                                "快手": [1152, 2126],
                                "斗鱼": [1133, 2126],
                                "花椒": [147, 875], "YY": [121, 1720], "映客": [199, 1786]}
        # self.coordinates = self.ios_coordinates[name]
        """点击开直播"""
        self.ios_coordinates = {"抖音3": [1037, 2129], "退出": [79, 2114], "退出游戏": [955, 2021], "皮皮虾": [1172, 2135],
                                "快手": [1152, 2126],
                                "斗鱼": [1133, 2126],
                                "花椒": [147, 875], "YY": [121, 1720], "映客": [199, 1786]}
        self.coordinates = self.ios_coordinates[name]

    def get_coordinates(self):
        """对应缩放因子在直播预览页切换摄像头点击"""
        return int(self.coordinates[0] / 3), int(self.coordinates[1] / 3)

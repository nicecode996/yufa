# -*- coding: utf-8 -*-
# @Time : 2020/9/6 8:32 下午
# @Author : Zhangfusheng
# @File : ios_scroll.py
class iOSScroll:
    def __init__(self, name):
        """需要维护在测试机上各个app切换前后摄像头的坐标位置"""
        # 直播入口
        self.ios_coordinates = {"右滑动切换直播间": [300, 2000, 300, 1000], "西瓜": [1153, 199, 0, 0], "火山": [1129, 93, 0, 0],
                                "皮皮虾": [1141, 145, 0, 0], "快手": [1148, 93, 0, 0], "斗鱼": [372, 112, 0, 0],
                                "花椒": [679, 2125, 0, 0], "YY": [1159, 2125, 0, 0], "映客": [773, 2125, 0, 0]}
        self.coordinates = self.ios_coordinates[name]

    def get_coordinates(self):
        """对应缩放因子在直播预览页切换摄像头点击"""
        return int(self.coordinates[0] / 3), int(self.coordinates[1] / 3), int(self.coordinates[2] / 3), int(
            self.coordinates[3] / 3)
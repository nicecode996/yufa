# -*- coding: utf-8 -*-
# @Time : 2020/8/3 11:51 上午
# @Author : Zhangfusheng
# @File : ios_click.py


class iOSClick:
    def __init__(self, name):
        """预览"""
        # self.ios_coordinates = {"抖音": [1130, 125], "西瓜": [881, 2114], "火山": [1162, 111], "皮皮虾": [1162, 111],
        #                         "快手": [1148, 93],
        #                         "斗鱼": [372, 112],
        #                         "花椒": [1153, 113], "YY": [1173, 113], "映客": [597, 127]}
        # self.coordinates = self.ios_coordinates[name]
        """直播中"""
        self.ios_coordinates = {"抖音": [378, 1283], "YY": [808, 2119], "西瓜": [443, 1673], "皮皮虾": [611, 1889],
                                "快手": [156, 1787], "空按钮": [590, 1300], "开播": [639, 1844], "直播间美化面板点击到调起": [756, 2133],
                                "斗鱼": [155, 1787], "页面控件": [691, 731], "自定": [208, 638], "点击按钮": [544, 524],
                                "花椒": [458, 1786], "火山": [1015, 2111], "映客": [851, 1288]}
        self.coordinates = self.ios_coordinates[name]
        # """同城"""
        # self.ios_coordinates = {"抖音": [415, 111], "退出": [79, 2114], "退出游戏": [955, 2021], "皮皮虾": [1172, 2135],
        #                         "快手": [347, 742],
        #                         "斗鱼": [1133, 2126],
        #                         "花椒": [147, 875], "YY": [121, 1720], "映客": [199, 1786]}
        # self.coordinates = self.ios_coordinates[name]

    def get_coordinates(self):
        """对应缩放因子在直播预览页切换摄像头点击"""
        return int(self.coordinates[0] / 3), int(self.coordinates[1] / 3)

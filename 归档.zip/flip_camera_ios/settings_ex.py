# -*- coding: utf8 -*-
"""project settings extension file:
    this file is in .gitignore;
    don't commit this file.
"""


